<?php
use GuzzleHttp\Client;
require_once __DIR__ . '/../vendor/autoload.php';

$settings = include_once 'settings.php';

$authParams = [
  'client_id' => $settings['client_id'],
  'client_secret' => $settings['client_secret'],
  'response_type' => 'code',
  'redirect_uri' => $settings['redirect_uri'],
  'scope' => implode(' ', $settings['scopes'])
];

$loginUrl = 'https://api.instagram.com/oauth/authorize?' . http_build_query($authParams);

?>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Kapitola 30 – Demo Instagram</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container">
      <h1>Kapitola 30 – Demo Instagram</h1>
      <div class="row">
        <div class="col-md-4 col-md-offset-4">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Přihlášení přes Instagram</h3>
            </div>
            <div class="panel-body">
              <a href="<?=$loginUrl?>" class="btn btn-block btn-primary">Přihlásit se přes Instagram</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
