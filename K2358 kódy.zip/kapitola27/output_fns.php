<?php
// Vypisuje záhlaví stránky.
function do_html_header($title) {
?>
<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <title><?php echo $title;?></title>
    <style>
      body { font-family: Arial, Helvetica, sans-serif; font-size: 13px }
      li, td { font-family: Arial, Helvetica, sans-serif; font-size: 13px }
      hr { color: #3333cc;}
      a { color: #000 }
      div.formblock {
        background: #ccc; width: 300px; padding: 6px; border: 1px solid #000;
      }
    </style>
  </head>
  <body>
    <div>
      <img src="bookmark.gif" alt="PHPbookmark logo" height="55" width="57"
           style="float: left; padding-right: 6px;" />
        <h1>PHPbookmark</h1>
    </div>
    <hr />
<?php
  if($title) {
    do_html_heading($title);
  }
}

// Vypisuje zápatí stránky.
function do_html_footer() {
?>
  </body>
  </html>
<?php
}

// Vypisuje nadpis.
function do_html_heading($heading) {
?>
  <h2><?php echo $heading;?></h2>
<?php
}

// Vypisuje adresu URL jako odkaz se zalomeními řádků.
function do_html_URL($url, $name) {
?>
  <br /><a href="<?php echo $url;?>"><?php echo $name;?></a><br />
<?php
}

// Zobrazuje marketingové informace.
function display_site_info() {
?>
  <ul>
    <li>Ukládejte si své záložky online s námi!</li>
    <li>Zjistěte, co používají ostatní uživatelé!</li>
    <li>Sdílejte své oblíbené odkazy s ostatními!</li>
  </ul>
<?php
}

function display_login_form() {
?>
  <p><a href="register_form.php">Nejste členem?</a></p>
  <form method="post" action="member.php">

    <div class="formblock">
      <h2>Přihlašování pro členy zde</h2>

      <p><label for="username">Uživatelské jméno:</label><br/>
      <input type="text" name="username" id="username" /></p>

      <p><label for="passwd">Heslo:</label><br/>
      <input type="password" name="passwd" id="passwd" /></p>

      <button type="submit">Přihlásit se</button>

      <p><a href="forgot_form.php">Zapomněl/a jste heslo?</a></p>
    </div>

 </form>
<?php
}

function display_registration_form() {
?>
  <form method="post" action="register_new.php">

    <div class="formblock">
      <h2>Registrujte se nyní</h2>

      <p>
        <label for="email">E-mailová adresa:</label><br/>
        <input type="email" name="email" id="email" 
          size="30" maxlength="100" required />
      </p>

      <p>
        <label for="username">
          Uživatelské jméno <br />(max. 16 znaků):
        </label><br/>
        <input type="text" name="username" id="username" 
          size="16" maxlength="16" required />
      </p>

      <p>
        <label for="passwd">Heslo <br />(min. 6 znaků):</label><br/>
        <input type="password" name="passwd" id="passwd" 
          size="16" maxlength="16" required />
      </p>

      <p>
        <label for="passwd2">Potvrzení hesla:</label><br/>
        <input type="password" name="passwd2" id="passwd2" 
          size="16" maxlength="16" required />
      </p>


      <button type="submit">Registrovat</button>

    </div>

  </form>
<?php
}

// Zobrazuje tabulku adres URL.
function display_user_urls($url_array) {
  // Nastavujeme globální proměnnou, abychom mohli později ověřit, jestli
  // se nachází tato tabulka na stránce.
  global $bm_table;
  $bm_table = true;
?>
  <br />
  <form name="bm_table" action="delete_bms.php" method="post">
    <table width="300" cellpadding="2" cellspacing="0">
<?php
  $color = "#cccccc";
  echo "<tr bgcolor=\"".$color."\"><td><strong>Záložka</strong></td>";
  echo "<td><strong>Smazat?</strong></td></tr>";
  if ((is_array($url_array)) && (count($url_array) > 0)) {
    foreach ($url_array as $url)  {
      if ($color == "#cccccc") {
        $color = "#ffffff";
      } else {
        $color = "#cccccc";
      }
      // Musíme zavolat funkci htmlspecialchars(), když vypisujeme data
      // od uživatele.
      echo "<tr bgcolor=\"".$color."\">
              <td>
                <a href=\"".$url."\">".htmlspecialchars($url)."</a>
              </td>
              <td>
                <input type=\"checkbox\" name=\"del_me[]\"
                  value=\"".$url."\">
              </td>
            </tr>";
    }
  } else {
    echo "<tr><td>Nebyly nalezeny žádné záložky.</td></tr>";
  }
?>
    </table>
  </form>
<?php
}

// Zobrazuje položky nabídky.
function display_user_menu() {
?>
  <hr />
  <a href="member.php">Domů</a> &nbsp;|&nbsp;
  <a href="add_bm_form.php">Přidat záložku</a> &nbsp;|&nbsp;
<?php
  // Zobrazíme odkaz "Smazat záložku" jen tehdy, když je zobrazená tabulka
  // záložek.
  global $bm_table;
  if ($bm_table == true) {
    echo "<a href=\"#\" onClick=\"bm_table.submit();\">Smazat záložku</a>
            &nbsp;|&nbsp;";
  } else {
    echo "<span style=\"color: #cccccc\">Smazat záložku</span> &nbsp;|&nbsp;";
  }
?>
  <a href="change_passwd_form.php">Změnit heslo</a><br />
  <a href="recommend.php">Doporučte mi adresy URL</a> &nbsp;|&nbsp;
  <a href="logout.php">Odhlásit se</a>
  <hr />

<?php
}

// Zobrazuje formulář pro vkládání nových záložek.
function display_add_bm_form() {
?>
  <form name="bm_table" action="add_bms.php" method="post">

    <div class="formblock">
      <h2>Nová záložka</h2>

      <p>
        <input type="text" name="new_url" id="new_url" 
          size="38" maxlength="255" value="http://" required />
      </p>

      <button type="submit">Přidat záložku</button>

    </div>

  </form>
<?php
}

// Zobrazuje formulář pro změnu hesla.
function display_password_form() {
?>
  <br />
  <form action="change_passwd.php" method="post">

    <div class="formblock">
      <h2>Změna hesla</h2>

      <p>
        <label for="old_passwd">Staré heslo:</label><br/>
        <input type="password" name="old_passwd" id="old_passwd" 
          size="16" maxlength="16" required />
      </p>

      <p>
        <label for="passwd2">Nové heslo:</label><br/>
        <input type="password" name="new_passwd" id="new_passwd" 
          size="16" maxlength="16" required />
      </p>

      <p>
        <label for="passwd2">Potvrzení nového hesla:</label><br/>
        <input type="password" name="new_passwd2" id="new_passwd2" 
          size="16" maxlength="16" required />
      </p>


      <button type="submit">Změnit heslo</button>

    </div>

  </form>
  <br />
<?php
}

// Zobrazuje formulář pro obnovu zapomenutého hesla.
function display_forgot_form() {
?>
  <br />
  <form action="forgot_passwd.php" method="post">

    <div class="formblock">
      <h2>Zapomněli jste heslo?</h2>

      <p>
        <label for="username">Zadejte své uživatelské jméno:</label><br/>
        <input type="text" name="username" id="username" 
          size="16" maxlength="16" required /></p>

      <button type="submit">Změnit heslo</button>

    </div>

  </form>
  <br />
<?php
}

// Zobrazuje podobnou tabulku jako funkce display_user_urls(), ale
// tentokrát s doporučenými záložkami namísto záložek uživatele.
function display_recommended_urls($url_array) {
?>
  <br />
  <table width="300" cellpadding="2" cellspacing="0">
<?php
  $color = "#cccccc";
  echo "<tr bgcolor=\"".$color."\">
        <td><strong>Doporučené záložky</strong></td></tr>";
  if ((is_array($url_array)) && (count($url_array) > 0)) {
    foreach ($url_array as $url) {
      if ($color == "#cccccc") {
        $color = "#ffffff";
      } else {
        $color = "#cccccc";
      }
      echo "<tr bgcolor=\"".$color."\">
              <td><a href=\"".$url."\">".htmlspecialchars($url)."</a></td>
            </tr>";
    }
  } else {
    echo "<tr><td>Žádná doporučení pro dnešní den.</td></tr>";
  }
?>
  </table>
<?php
}

?>
