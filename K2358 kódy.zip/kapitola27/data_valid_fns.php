<?php

// Testuje, zda formulářové proměnné mají hodnoty.
function filled_out($form_vars) {
  foreach ($form_vars as $key => $value) {
    if ((!isset($key)) || ($value == '')) {
      return false;
    }
  }
  return true;
}

// Ověřuje, jestli má e-mailová adresa platný formát.
function valid_email($address) {
  if (preg_match('/^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$/',
      $address)) {
    return true;
  } else {
    return false;
  }
}

?>
