<?php
  require_once("bookmark_fns.php");
  do_html_header("Obnova hesla");

  // Vytváříme zkrácené názvy proměnných.
  $username = $_POST['username'];

  try {
    $password = reset_password($username);
    notify_password($username, $password);
    echo 'Vaše nové heslo bylo odesláno na vaši e-mailovou adresu.<br>';
  } catch (Exception $e) {
    echo 'Vaše heslo se nepodařilo obnovit – prosíme, zkuste to později.';
  }
  do_html_url('login.php', 'Přihlásit se');
  do_html_footer();
?>
