<?php

// Vkládáme soubory funkcí pro tuto aplikaci.
require_once('bookmark_fns.php');
session_start();

// Vytváříme zkrácené názvy proměnných.
if (!isset($_POST['username']))  {
  // Pokud není nastavené, nastavíme prázdnou hodnotu.
  $_POST['username'] = "";
}
$username = $_POST['username'];
if (!isset($_POST['passwd']))  {
  // Pokud není nastavené, nastavíme prázdnou hodnotu.
  $_POST['passwd'] = "";
}
$passwd = $_POST['passwd'];

if ($username && $passwd) {
  // Uživatel se pokusil přihlásit.
  try {
    login($username, $passwd);
    // Protože jsme našli uživatele v databázi, uložíme si jeho
    // uživatelské jméno do relační proměnné.
    $_SESSION['valid_user'] = $username;
  } catch (Exception $e)  {
    // Přihlašování se nezdařilo.
    do_html_header('Problém:');
    echo 'Přihlašování se nezdařilo.<br>
          Musíte se přihlásit, abyste mohl/a prohlížet tuto stránku.';
    do_html_url('login.php', 'Přihlásit se');
    do_html_footer();
    exit;
  }
}

do_html_header('Domovská stránka');
check_valid_user();
// Načteme záložky, které si aktuální uživatel uložil.
if ($url_array = get_user_urls($_SESSION['valid_user'])) {
  display_user_urls($url_array);
}

// Zobrazujeme nabídku.
display_user_menu();

do_html_footer();
?>
