<?php
// Vkládáme soubory s funkcemi pro tuto aplikaci.
require_once('bookmark_fns.php');
session_start();

// Začínáme vypisovat kód HTML.
do_html_header('Přidávání záložek');

check_valid_user();
display_add_bm_form();

display_user_menu();
do_html_footer();

?>
