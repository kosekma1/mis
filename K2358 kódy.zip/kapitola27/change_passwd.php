<?php
  require_once('bookmark_fns.php');
  session_start();
  do_html_header('Změna hesla');

  // Vytváříme zkrácené názvy proměnných.
  $old_passwd = $_POST['old_passwd'];
  $new_passwd = $_POST['new_passwd'];
  $new_passwd2 = $_POST['new_passwd2'];

  try {
    check_valid_user();
    if (!filled_out($_POST)) {
      throw new Exception('Nevyplnil/a jste formulář správně. Prosíme,
                           zkuste to znovu.');
    }

    if ($new_passwd != $new_passwd2) {
      throw new Exception('Zadaná hesla se neshodují. Prosíme, zkuste
                           to znovu.');
    }

    if (strlen($new_passwd) < 6) {
      throw new Exception('Vaše heslo musí mít minimálně 6 znaků. Prosíme,
                           zkuste to znovu.');
    }

    // Pokusíme se provést změnu.
    change_password($_SESSION['valid_user'], $old_passwd, $new_passwd);
    echo 'Heslo bylo úspěšně změněno.';
  } catch (Exception $e) {
    echo $e->getMessage();
  }
  display_user_menu();
  do_html_footer();
?>
