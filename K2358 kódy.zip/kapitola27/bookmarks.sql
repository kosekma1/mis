CREATE DATABASE bookmarks;
USE bookmarks;

CREATE TABLE user (
  username VARCHAR(16) PRIMARY KEY,
  passwd CHAR(40) NOT NULL,
  email VARCHAR(100) NOT NULL
);

CREATE TABLE bookmark (
  username VARCHAR(16) NOT NULL,
  bm_URL VARCHAR(255) NOT NULL,
  INDEX (username),
  INDEX (bm_URL)
);

GRANT SELECT, INSERT, UPDATE, DELETE
  ON bookmarks.*
  TO bm_user@localhost identified by 'heslo';
