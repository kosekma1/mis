<?php
require_once('db_fns.php');

// Načítá z databáze všechny adresy URL, které si daný uživatel ulžožil.
function get_user_urls($username) {

  $conn = db_connect();
  $result = $conn->query("SELECT bm_URL
                            FROM bookmark
                            WHERE username = '".$username."'");
  if (!$result) {
    return false;
  }

  // Vytváříme pole adres URL.
  $url_array = array();
  for ($count = 1; $row = $result->fetch_row(); ++$count) {
    $url_array[$count] = $row[0];
  }
  return $url_array;
}

// Přidává novou záložku do databáze.
function add_bm($new_url) {

  echo "Pokus o přidání ".htmlspecialchars($new_url)."<br />";
  $valid_user = $_SESSION['valid_user'];

  $conn = db_connect();

  // Zkontrolujeme, jestli už tuto záložku nemáme.
  $result = $conn->query("SELECT *
                            FROM bookmark
                            WHERE username = '$valid_user' AND
                              bm_URL = '".$new_url."'");
  if ($result && ($result->num_rows > 0)) {
    throw new Exception('Tato záložka už existuje.');
  }

  // Vkládáme novou záložku.
  if (!$conn->query("INSERT INTO bookmark VALUES
                       ('".$valid_user."', '".$new_url."')")) {
    throw new Exception('Záložku se nepodařilo uložit.');
  }

  return true;
}

// Maže adresu URL z databáze.
function delete_bm($user, $url) {
  $conn = db_connect();

  // Maže danou záložku.
  if (!$conn->query("DELETE FROM bookmark
                       WHERE
                         username = '".$user."' AND
                         bm_url = '".$url."'")) {
    throw new Exception('Záložku se nepodařilo smazat.');
  }
  return true;
}

// Poskytuje inteligentní doporučení lidem. Jestliže mají nějaké společné
// adresy URL s ostatními uživateli, pravděpodobně budou mít rádi také
// jiné adresy URL, které mají tito lidé.
function recommend_urls($valid_user, $popularity = 1) {
  $conn = db_connect();

  // Hledáme jiné uživatele, kteří mají stejnou adresu URL s tímto
  // uživatelem. Tím vyloučíme soukromé stránky a zvýšíme šanci, že
  // uživatel bude s výběrem spokojený. Definujeme minimální úroveň
  // popularity. Pokud bude $popularity = 1, více než jeden člověk
  // musí mít uloženou adresu URL, než ji doporučíme.

  $query = "SELECT bm_URL
              FROM bookmark
              WHERE
                username IN
                  (SELECT DISTINCT(b2.username)
                     FROM bookmark b1, bookmark b2
                     WHERE b1.username = '".$valid_user."' AND
                       b1.username != b2.username AND
                       b1.bm_URL = b2.bm_URL) AND
                bm_URL NOT IN
                  (SELECT bm_URL
                     FROM bookmark
                     WHERE username = '".$valid_user."')
              GROUP BY bm_url
              HAVING COUNT(bm_url) > ".$popularity;

  if (!($result = $conn->query($query))) {
     throw new Exception('Nepodařilo se najít žádné doporučené záložky.');
  }

  if ($result->num_rows == 0) {
     throw new Exception('Nepodařilo se najít žádné doporučené záložky.');
  }

  $urls = array();
  // Vytváříme pole vybraných adres URL.
  for ($count = 0; $row = $result->fetch_object(); $count++) {
    $urls[$count] = $row->bm_URL;
  }

  return $urls;
}
?>
