<?php

// Vkládáme soubory s funkcemi pro tuto aplikaci.
require_once('bookmark_fns.php');
session_start();

// Ukládáme si původní hodnotu relační proměnné, abychom dále mohli
// zjistit, jestli byl uživatel přihlášený.
$old_user = $_SESSION['valid_user'];

unset($_SESSION['valid_user']);
$result_dest = session_destroy();

// Začneme vypisovat kód HTML.
do_html_header('Odhlášení');

if (!empty($old_user)) {
  if ($result_dest)  {
    // Uživatel byl přihlášený a nyní se odhlásil.
    echo 'Byl/a jste úspěšně odhlášen/a.<br>';
    do_html_url('login.php', 'Přihlásit se');
  } else {
    // Uživatel byl přihlášený, ale nyní se ho nepodařilo zcela odhlásit.
    echo 'Odhlašování selhalo.<br>';
  }
} else {
  // Uživatel nebyl přihlášený, ale dostal se nějakým způsobem na tuto
  // stránku.
  echo 'Nebyl/a jste přihlášený/á, takže odhlašování neproběhlo.<br>';
  do_html_url('login.php', 'Přihlásit se');
}

do_html_footer();

?>
