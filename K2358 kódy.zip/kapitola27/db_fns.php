<?php

function db_connect() {
  $result = new mysqli('localhost', 'bm_user', 'heslo', 'bookmarks');
  if (!$result) {
    throw new Exception('Nepodařilo se připojit k databázi.');
  } else {
    return $result;
  }
}

?>
