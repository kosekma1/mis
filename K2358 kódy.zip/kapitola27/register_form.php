<?php
  require_once('bookmark_fns.php');
  do_html_header('Registrace uživatele');

  display_registration_form();

  do_html_footer();
?>
