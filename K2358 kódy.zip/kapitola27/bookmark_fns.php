<?php
  // Tento soubor můžeme vkládat do všech stránek. Díky tomu budou všechny
  // stránky obsahovat všechny funkce a výjimky.
  require_once('data_valid_fns.php'); 
  require_once('db_fns.php');
  require_once('user_auth_fns.php');
  require_once('output_fns.php');
  require_once('url_fns.php');
?>
