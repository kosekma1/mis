<?php
  // Vkládáme knihovny funkcí pro tuto aplikaci.
  require_once('bookmark_fns.php');

  // Vytváříme zkrácené názvy proměnných.
  $email = $_POST['email'];
  $username = $_POST['username'];
  $passwd = $_POST['passwd'];
  $passwd2 = $_POST['passwd2'];
  // Spouštíme relaci, kterou budeme potřebovat později.
  // Spouštíme ji však teď, protože musí předcházet hlavičkám.
  session_start();
  try {
    // Validujeme vyplněná formulářová data.

    if (!filled_out($_POST)) {
      throw new Exception('Nevyplnil/a jste formulář správně. Prosíme,
                           vraťte se zpět a zkuste to znovu.');
    }

    // E-mailová adresa není platná.
    if (!valid_email($email)) {
      throw new Exception('Neplatná e-mailová adresa. Prosíme, vraťte se
                           zpět a zkuste to znovu.');
    }

    // Hesla se liší.
    if ($passwd != $passwd2) {
      throw new Exception('Zadaná hesla se neshodují. Prosíme, vraťte se
                           zpět a zkuste to znovu.');
    }

    // Zkontrolujeme délku uživatelského jména.
    if (strlen($username) > 16) {
      throw new Exception('Vaše uživatelské jméno musí mít maximálně 16 znaků.
                           Prosíme, vraťte se zpět a zkuste to znovu.');
    }

    // Zkontrolujeme délku hesla.
    if (strlen($passwd) < 6) {
      throw new Exception('Vaše heslo musí mít minimálně 6 znaků. Prosíme,
                           vraťte se zpět a zkuste to znovu.');
    }

    // Pokusíme se zaregistrovat uživatele.
    // Tato funkce může vyvolat výjimku.
    register($username, $email, $passwd);
    // Zaregistrujeme relační proměnné.
    $_SESSION['valid_user'] = $username;

    // Zobrazujeme odkaz na stránku pro členy.
    do_html_header('Registrace proběhla úspěšně');
    echo 'Vaše registrace proběhla úspěšně. Navštivte stránku pro členy,
          abyste mohli začít přidávat své záložky.';
    do_html_url('member.php', 'Přejít na stránku pro členy');

    // Konec stránky
    do_html_footer();
  } catch (Exception $e) {
    do_html_header('Problém:');
    echo $e->getMessage();
    do_html_footer();
    exit;
  }
?>
