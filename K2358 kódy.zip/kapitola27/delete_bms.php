<?php
  require_once('bookmark_fns.php');
  session_start();

  // Vytváříme zkrácené názvy proměnných.
  $del_me = $_POST['del_me'];
  $valid_user = $_SESSION['valid_user'];

  do_html_header('Mazání záložek');
  check_valid_user();

  if (!filled_out($_POST)) {
    echo '<p>Nevybral/a jste si žádné záložky ke smazání. Prosíme, zkuste
          to znovu.</p>';
    display_user_menu();
    do_html_footer();
    exit;
  } else {
    if (count($del_me) > 0) {
      foreach($del_me as $url) {
        if (delete_bm($valid_user, $url)) {
          echo 'Smazána adresa '.htmlspecialchars($url).'.<br>';
        } else {
          echo 'Nepodařilo se smazat adresu '.htmlspecialchars($url).
               '.<br>';
        }
      }
    } else {
      echo '<p>Nevybral/a jste si žádné záložky ke smazání. Prosíme, zkuste
            to znovu.</p>';
    }
  }

  // Načítáme záložky, které si uložil aktuální uživatel.
  if ($url_array = get_user_urls($valid_user)) {
    display_user_urls($url_array);
  }

  display_user_menu();
  do_html_footer();
?>
