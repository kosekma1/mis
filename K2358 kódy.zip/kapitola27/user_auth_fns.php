<?php

require_once('db_fns.php');

// Registruje nového uživatele – vkládá jeho údaje do databáze.
// Vrací hodnotu true nebo vyvolává chybovou zprávu.
function register($username, $email, $password) {

  // Připojujeme se k databázi.
  $conn = db_connect();

  // Ověřujeme, jestli je uživatelské jméno jedinečné.
  $result = $conn->query("SELECT *
                            FROM user
                            WHERE username = '".$username."'");
  if (!$result) {
    throw new Exception('Nepodařilo se provést dotaz.');
  }

  if ($result->num_rows > 0) {
    throw new Exception('Zadané uživatelské jméno už existuje – vraťte se
                         zpět a vyberte si jiné.');
  }

  // Jestliže vše proběhlo v pořádku, vložíme nový záznam do databáze.
  $result = $conn->query("INSERT INTO user VALUES
                            ('".$username."', sha1('".$password."'),
                            '".$email."')");
  if (!$result) {
    throw new Exception('Registrace se nezdařila – zkuste to prosím
                         později.');
  }

  return true;
}

// Vyhledá kombinaci uživatelského jména a hesla v databázi. Pokud ji
// najde, vrátí hodnotu true; v opačném případě vyhodí výjimku.
function login($username, $password) {

  // Připojujeme se k databázi.
  $conn = db_connect();

  // Ověřujeme, jestli v databázi existuje daná kombinace uživatelského
  // jména a hesla.
  $result = $conn->query("SELECT *
                            FROM user
                            WHERE username='".$username."' AND
                              passwd = sha1('".$password."')");
  if (!$result) {
    throw new Exception('Přihlášení se nezdařilo.');
  }

  if ($result->num_rows > 0) {
    return true;
  } else {
    throw new Exception('Přihlášení se nezdařilo.');
  }
}

// Ověřuje, jestli je uživatel přihlášený. Pokud není, upozorní ho.
function check_valid_user() {
  if (isset($_SESSION['valid_user']))  {
    echo "Jste přihlášen/a jako ".$_SESSION['valid_user'].".<br>";
  } else {
    // Uživatel není přihlášený.
    do_html_header('Problém:');
    echo 'Nejste přihlášen/a.<br>';
    do_html_url('login.php', 'Přihlásit se');
    do_html_footer();
    exit;
  }
}

// Mění heslo daného uživatele, a to ze starého hesla na nové.
// Vrací hodnotu true nebo false.
function change_password($username, $old_password, $new_password) {

  // Jestliže je staré heslo správné, změníme ho na nové a vrátíme
  // hodnotu true; jinak vyhazujeme výjimku.
  login($username, $old_password);
  $conn = db_connect();
  $result = $conn->query("UPDATE user
                            SET passwd = sha1('".$new_password."')
                            WHERE username = '".$username."'");
  if (!$result) {
    throw new Exception('Heslo se nepodařilo změnit.');
  } else {
    return true;  // Heslo bylo změněno úspěšně.
  }
}

// Načítá náhodné slovo ze slovníku, a to v daném rozmezí délky.
function get_random_word($min_length, $max_length) {

  $word = '';
  // Nezpomeňte změnit tuto cestu tak, aby odpovídala vašemu systému.
  $dictionary = '/usr/dict/words';  // slovník ispell
  $fp = @fopen($dictionary, 'r');
  if (!$fp) {
    return false;
  }
  $size = filesize($dictionary);

  // Přejdeme na náhodnou pozici ve slovníku.
  $rand_location = rand(0, $size);
  fseek($fp, $rand_location);

  // Najdeme další celé slovo.
  while ((strlen($word) < $min_length) || (strlen($word) > $max_length) ||
      (strstr($word, "'"))) {
    if (feof($fp)) {
      // Jsme na konci, takže se vrátíme na začátek.
      fseek($fp, 0);
    }
    // Přeskočíme první slovo, protože by mohlo být jen částečné.
    $word = fgets($fp, 80);
    $word = fgets($fp, 80); // Toto je potenciální heslo.
  }
  $word = trim($word); // Ořezává znaky \n z konců slova.
  return $word;
}

// Nastavuje heslo uživatele na náhodnou hodnotu. Vrací toto nové heslo
// nebo hodnotu false, pokud se to nepodaří.
function reset_password($username) {
  // Vybíráme náhodné slovo ze slovníku (mezi 6 a 13 znaky).
  $new_password = get_random_word(6, 13);

  if ($new_password == false) {
    // Nastavujeme výchozí heslo.
    $new_password = "změňMě!";
  }

  // Přičítáme k heslu číslo mezi 0 až 999, abychom ho trochu vylepšili.
  $rand_number = rand(0, 999);
  $new_password .= $rand_number;

  // Nastavujeme uživateli nové heslo. Pokud se to nezdaří, vrátíme
  // hodnotu false.
  $conn = db_connect();
  $result = $conn->query("UPDATE user
                            SET passwd = sha1('".$new_password."')
                            WHERE username = '".$username."'");
  if (!$result) {
    throw new Exception('Heslo se nepodařilo změnit.');
  } else {
    return $new_password;  // Heslo bylo změněno úspěšně.
  }
}

// Upozorňuje uživatele, že heslo se podařilo úspěšně změnit.
function notify_password($username, $password) {

    $conn = db_connect();
    $result = $conn->query("SELECT email
                              FROM user
                              WHERE username = '".$username."'");
    if (!$result) {
      throw new Exception('Nepodařilo se najít e-mailovou adresu.');
    } else if ($result->num_rows == 0) {
      // Nenašli jsme záznam uživatele v databázi.
      throw new Exception('Nepodařilo se najít e-mailovou adresu.');
    } else {
      $row = $result->fetch_object();
      $email = $row->email;
      $from = "From: podpora@phpbookmark.cz\r\n";
      $mesg = "Vaše heslo k systému PHPBookmark bylo změněno na ".
              $password."\r\n"
              ."Prosíme, změňte si ho, až se příště přihlásíte.\r\n";

      if (mail($email, 'Přihlašovací údaje PHPBookmark', $mesg, $from)) {
        return true;
      } else {
        throw new Exception('Nepodařilo se odeslat e-mail.');
      }
    }
}

?>
