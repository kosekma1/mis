<?php
// vytváříme obrazové plátno
$width = 200;
$height = 200;
$im = imagecreatetruecolor($width, $height);
$white = imagecolorallocate($im, 255, 255, 255);
$blue = imagecolorallocate($im, 0, 0, 255);

// kreslíme obrázek
imagefill($im, 0, 0, $blue);
imageline($im, 0, 0, $width, $height, $white);
imagestring($im, 4, 50, 150, 'Prodej', $white);

// výstup obrázku
header('Content-type: image/png');
imagepng($im);

// úklid
imagedestroy($im);
?>
