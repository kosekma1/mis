<?php
/* Nastavíme datum narození pro výpočet. Datum narození musí mít den,
   měsíc a rok. */
$day = 18;
$month = 9;
$year = 1972;

// Určíme časovou známku pro datum narození.
$bdayunix = mktime(0, 0, 0, $month, $day, $year);
// Určíme časovou známku pro dnešek.
$nowunix = time();
// Spočítáme rozdíl.
$ageunix = $nowunix - $bdayunix;
// Převedeme rozdíl ze sekund na roky.
$age = floor($ageunix / (365 * 24 * 60 * 60));

echo 'Současný věk je '.$age.'.';
?>
