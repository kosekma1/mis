<?php
/* Nastavíme datum narození pro výpočet. Datum narození musí mít den,
   měsíc a rok. */
$day = 18;
$month = 9;
$year = 1972;

// Naformátujeme datum narození dle standardu ISO 8601.
$bdayISO = date("c", mktime(0, 0, 0, $month, $day, $year));

// Použijeme dotaz SQL, abychom vypočítali věk v dnech.
$db = mysqli_connect('localhost', 'uzivatel', 'heslo');
$res = mysqli_query($db, "SELECT datediff(now(), '$bdayISO')");
$age = mysqli_fetch_array($res);

// Převedeme věk v dnech na roky (přibližně).
echo 'Současný věk je '.floor($age[0] / 365.25).'.';
?>
