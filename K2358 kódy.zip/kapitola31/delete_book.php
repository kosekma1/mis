<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Mazání knihy");
if (check_admin_user()) {
  if (isset($_POST['isbn'])) {
    $isbn = $_POST['isbn'];
    if(delete_book($isbn)) {
      echo "<p>Kniha ".htmlspecialchars($isbn)." byla smazána.</p>";
    } else {
      echo "<p>Knihu ".htmlspecialchars($isbn)." se nepodařilo smazat.</p>";
    }
  } else {
    echo "<p>Musí být známý kód ISBN, aby bylo možné smazat knihu. Prosíme, zkuste to znovu.</p>";
  }
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku</p>";
}

do_html_footer();

?>
