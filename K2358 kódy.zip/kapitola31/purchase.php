<?php

  include ('book_sc_fns.php');
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  do_html_header("Pokladna");

  // Vytváříme zkrácené názvy proměnných.
  $name = $_POST['name'];
  $address = $_POST['address'];
  $city = $_POST['city'];
  $zip = $_POST['zip'];
  $country = $_POST['country'];

  // Pokud máme vyplněné následující údaje...
  if (($_SESSION['cart']) && ($name) && ($address) && ($city) && ($zip) && ($country)) {
    // a podařilo se je vložit do databáze.
    if (insert_order($_POST) != false ) {
      // Zobrazíme košík, v němž neumožníme dělat změny a vypustíme obrázky.
      display_cart($_SESSION['cart'], false, 0);

      display_shipping(calculate_shipping_cost());

      // Zobrazíme formulář platební karty.
      display_card_form($name);

      display_button("show_cart.php", "continue-shopping", "Dále nakupovat");
    } else {
      echo "<p>Nepodařilo se uložit data. Prosíme, zkuste to znovu.</p>";
      display_button('checkout.php', 'back', 'Zpět');
    }
  } else {
    echo "<p>Nevyplnil/a jste včechna pole. Prosíme, zkuste to znovu.</p><hr />";
    display_button('checkout.php', 'back', 'Zpět');
  }

  do_html_footer();
?>
