<?php
  require_once('book_sc_fns.php');
  session_start();
  do_html_header("Změna hesla");
  check_admin_user();

  display_password_form();

  do_html_url("admin.php", "Zpět k administrační nabídce");
  do_html_footer();
?>
