<?php
  include ('book_sc_fns.php');
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  $isbn = $_GET['isbn'];

  // Načítáme knihu z databáze.
  $book = get_book_details($isbn);
  do_html_header($book['title']);
  display_book_details($book);

  // Uložíme adresu URL tlačítka pro pokračování.
  $target = "index.php";
  if ($book['catid']) {
    $target = "show_cat.php?catid=". urlencode($book['catid']);
  }

  // Jestliže je přihlášený správce, zobrazíme odkaz pro editaci knihy.
  if (check_admin_user()) {
    display_button("edit_book_form.php?isbn=". urlencode($isbn), "edit-item", "Editovat položku");
    display_button("admin.php", "admin-menu", "Nabídka administrace");
    display_button($target, "continue", "Pokračovat");
  } else {
    display_button("show_cart.php?new=". urlencode($isbn), "add-to-cart",
                   "Přidat ". htmlspecialchars($book['title']) . " do mého nákupního košíku");
    display_button($target, "continue-shopping", "Dále nakupovat");
  }

  do_html_footer();
?>
