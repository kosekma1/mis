<?php
  include_once 'book_sc_fns.php';
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();
  do_html_header("Vítejte v obchodě Book-O-Rama");

  echo "<p>Prosíme, vyberte si kategorii:</p>";

  // Načítáme kategorie z databáze.
  $cat_array = get_categories();

  // Zobrazujeme odkazy na stránky kategorií.
  display_categories($cat_array);

  // Jestliže je přihlášený správce, zobrazíme odkazy pro přidání, mazání
  // a editaci kategorie.
  if (isset($_SESSION['admin_user'])) {
    display_button("admin.php", "admin-menu", "Nabídka administrace");
  }
  do_html_footer();
?>
