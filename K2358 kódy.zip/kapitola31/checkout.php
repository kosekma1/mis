<?php
  // Vkládáme naši sadu funkcí.
  include ('book_sc_fns.php');

  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  do_html_header("Pokladna");

  if (($_SESSION['cart']) && (array_count_values($_SESSION['cart']))) {
    display_cart($_SESSION['cart'], false, 0);
    display_checkout_form();
  } else {
    echo "<p>Váš košík neobsahuje žádné položky.</p>";
  }

  display_button("show_cart.php", "continue-shopping", "Dále nakupovat");

  do_html_footer();
?>
