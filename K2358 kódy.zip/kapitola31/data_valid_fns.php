<?php

// Ověřuje, zda mají všechny proměnné hodnotu.
function filled_out($form_vars) {
  foreach ($form_vars as $key => $value) {
    if ((!isset($key)) || ($value == '')) {
      return false;
    }
  }
  return true;
}

// Ověřuje, jestli je e-mailová adresa platná.
function valid_email($address) {
  return filter_var($address, FILTER_VALIDATE_EMAIL);
}

?>
