<?php

require_once('book_sc_fns.php');
session_start();

// Uživatel se pokouší přihlásit.
if (isset($_POST['username']) && isset($_POST['passwd'])) {
  $username = $_POST['username'];
  $passwd = $_POST['passwd'];

  if (login($username, $passwd)) {
    // Pokud najdeme uživatele v databázi, poznačíme si jeho uživatelské
    // jméno do relace.
    $_SESSION['admin_user'] = $username;
  } else {
    // Neúspěšný pokus o přihlášení.
    do_html_header("Problém:");
    echo "<p>Přihlášení se nezdařilo.<br/>
          Musíte se přihlásit, abyste mohli prohlížet tuto stránku.</p>";
    do_html_url('login.php', 'Přihlášení');
    do_html_footer();
    exit;
  }
}

do_html_header("Administrace");
if (check_admin_user()) {
  display_admin_menu();
} else {
  echo "<p>Nejste oprávněn/a vstoupit do administrační oblasti.</p>";
}
do_html_footer();

?>
