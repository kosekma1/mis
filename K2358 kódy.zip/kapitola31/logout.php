<?php

require_once('book_sc_fns.php');
session_start();
$old_user = $_SESSION['admin_user'];
unset($_SESSION['admin_user']);
session_destroy();

// Začátek výstupu kódu HTML.
do_html_header("Odhlášení");

if (!empty($old_user)) {
  echo "<p>Odhlášení proběhlo úspěšně.</p>";
  do_html_url("login.php", "Přihlásit se");
} else {
  // Pokud uživatel nebyl přihlášen, ale nějak se dostal na tuto stránku.
  echo "<p>Nepřihlásil/a jste se, proto se nemůžete odhlásit.</p>";
  do_html_url("login.php", "Přihlásit se");
}

do_html_footer();

?>
