<?php
  include ('book_sc_fns.php');
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  @$new = $_GET['new'];

  if ($new) {
    // Máme vytvořit novou položku.

    if (!isset($_SESSION['cart'])) {
      $_SESSION['cart'] = array();
      $_SESSION['items'] = 0;
      $_SESSION['total_price'] ='0.00';
    }

    if (isset($_SESSION['cart'][$new])) {
      $_SESSION['cart'][$new]++;
    } else {
      $_SESSION['cart'][$new] = 1;
    }

    $_SESSION['total_price'] = calculate_price($_SESSION['cart']);
    $_SESSION['items'] = calculate_items($_SESSION['cart']);
  }

  if (isset($_POST['save'])) {
    foreach ($_SESSION['cart'] as $isbn => $qty) {
      if ($_POST[$isbn] == '0') {
        unset($_SESSION['cart'][$isbn]);
      } else {
        $_SESSION['cart'][$isbn] = $_POST[$isbn];
      }
    }

    $_SESSION['total_price'] = calculate_price($_SESSION['cart']);
    $_SESSION['items'] = calculate_items($_SESSION['cart']);
  }

  do_html_header("Váš nákupní košík");

  if (isset($_SESSION['cart']) && array_count_values($_SESSION['cart'])) {
    display_cart($_SESSION['cart']);
  } else {
    echo "<p>Váš košík neobsahuje žádné položky.</p><hr/>";
  }

  $target = "index.php";

  // Pokud jsme přidali položku do košíku, umožníme uživateli pokračovat
  // v nakupování v kategorii odpovídající této položce.
  if ($new) {
    $details = get_book_details($new);
    if ($details['catid']) {
      $target = "show_cat.php?catid=".urlencode($details['catid']);
    }
  }
  display_button($target, "continue-shopping", "Dále nakupovat");

  // Jestliže používáte vrstvu SSL, použijte tento kód.
  // $path = $_SERVER['PHP_SELF'];
  // $server = $_SERVER['SERVER_NAME'];
  // $path = str_replace('show_cart.php', '', $path);
  // display_button("https://".$server.$path."checkout.php",
  //                 "go-to-checkout", "Přejít k pokladně");

  // V případě, že nepoužíváte vrstvu SSL, použijte následující kód.
  display_button("checkout.php", "go-to-checkout", "Přejít k pokladně");

  do_html_footer();
?>
