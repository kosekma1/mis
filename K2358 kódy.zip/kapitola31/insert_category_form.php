<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Přidání kategorie");
if (check_admin_user()) {
  display_category_form();
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku.</p>";
}
do_html_footer();

?>
