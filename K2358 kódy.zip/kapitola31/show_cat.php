<?php
  include ('book_sc_fns.php');
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  $catid = $_GET['catid'];
  $name = get_category_name($catid);

  do_html_header($name);

  // Načítáme informace o knize z databáze.
  $book_array = get_books($catid);

  display_books($book_array);


  // Jestliže je přihlášený správce, zobrazíme odkazy pro přidání, mazání
  // a editaci kategorie.
  if (isset($_SESSION['admin_user'])) {
    display_button("index.php", "continue", "Dále nakupovat");
    display_button("admin.php", "admin-menu", "Nabídka administrace");
    display_button("edit_category_form.php?catid=". urlencode($catid),
                   "edit-category", "Editovat kategorii");
  } else {
    display_button("index.php", "continue-shopping", "Dále nakupovat");
  }

  do_html_footer();
?>
