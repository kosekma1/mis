<?php
  require_once('book_sc_fns.php');
  session_start();
  do_html_header('Změna hesla');
  check_admin_user();
  if (!filled_out($_POST)) {
    echo "<p>Nevyplnil/a jste včechna pole. Prosíme, zkuste to znovu.</p>";
    do_html_url("admin.php", "Zpět k administrační nabídce");
    do_html_footer();
    exit;
  } else {
    $new_passwd = $_POST['new_passwd'];
    $new_passwd2 = $_POST['new_passwd2'];
    $old_passwd = $_POST['old_passwd'];
    if ($new_passwd != $new_passwd2) {
      echo "<p>Zadaná hesla se neshodují. Změna nebyla provedena.</p>";
    } else if ((strlen($new_passwd)>16) || (strlen($new_passwd)<6)) {
      echo "<p>Nové heslo musí být mezi 6 a 16 znaky. Zkuste to znovu.</p>";
    } else {
      // Pokus o změnu
      if (change_password($_SESSION['admin_user'], $old_passwd, $new_passwd)) {
        echo "<p>Heslo bylo změněno.</p>";
      } else {
        echo "<p>Heslo se nepodařilo změnit.</p>";
      }
    }
  }
  do_html_url("admin.php", "Zpět k administrační nabídce");
  do_html_footer();
?>
