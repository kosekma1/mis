USE book_sc;
SET NAMES utf8;

INSERT INTO books VALUES (
    '9788025137505',
    'Ondřej Baše',
    'jQuery pro neprogramátory',
    1,
    424,
    'Dozvíte se, jak vylepšit svůj web o praktické prvky (formuláře, galerie, multimédia), jejichž používání bude návštěvníky bavit a nevyžene je při prvním špatně zadaném vstupu.'
  ), (
    '9788025147375',
    'Timothy Boronczyk',
    'MySQL Okamžitě',
    1,
    212,
    'Seznamte se za víkend se základy databázového jazyka MySQL, který využívá celá řada internetových služeb. Nabyté znalosti poté můžete využít nejen v oblasti webových projektů, ale i v samostatných databázových systémech.'
  ), (
    '9788025141960',
    'Callum Hopkins',
    'PHP Okamžitě',
    1,
    212,
    'Seznamte se za víkend s jazykem PHP, který běží na pozadí 80% webů včetně Facebooku, Wikipedie nebo WordPressu. Naučíte se, jak pomocí PHP převést statické stránky na dynamickou webovou aplikaci s bohatými funkcemi.'
  );

INSERT INTO categories VALUES (1, 'Internet');
INSERT INTO categories VALUES (2, 'Hobby');
INSERT INTO categories VALUES (5, 'Fikce');
INSERT INTO categories VALUES (4, 'Zahrada');

INSERT INTO admin VALUES ('admin', sha1('admin'));
