<?php

// Připojuje se k platební bráně nebo používá GPG k šifrování a odesílá
// e-mail, případně ukládá údaje do databáze. 
function process_card($card_details) {
  return true;
}

function insert_order($order_details) {
  // Extrahuje údaje o objednávce do proměnných.
  extract($order_details);

  // Nastavujeme doručovací adresu shodně s fakturační.
  if ((!$ship_name) && (!$ship_address) && (!$ship_city) &&
  	  (!$ship_zip) && (!$ship_country)) {
    $ship_name = $name;
    $ship_address = $address;
    $ship_city = $city;
    $ship_zip = $zip;
    $ship_country = $country;
  }

  $conn = db_connect();

  // Chceme vložit objednávku jako transakci.
  // Zahájíme transakci tak, že vypneme autocommit.
  $conn->autocommit(FALSE);

  // Vkládáme adresu zákazníka, pokud neexistuje.
  $query = "SELECT customerid
              FROM customers
              WHERE name = '".$conn->real_escape_string($name) ."' AND
                address = '". $conn->real_escape_string($address)."' AND
                city = '".$conn->real_escape_string($city)."' AND
                zip = '".$conn->real_escape_string($zip)."' AND
                country = '".$conn->real_escape_string($country)."'";

  $result = $conn->query($query);

  if ($result->num_rows > 0) {
    $customer = $result->fetch_object();
    $customerid = $customer->customerid;
  } else {
    $query = "INSERT INTO customers VALUES
                (NULL, '" . $conn->real_escape_string($name) ."','" .
                $conn->real_escape_string($address) . "','".
                $conn->real_escape_string($city) ."','".
                $conn->real_escape_string($zip) ."','".
                $conn->real_escape_string($country)."')";
    $result = $conn->query($query);

    if (!$result) {
       return false;
    }
  }

  $customerid = $conn->insert_id;

  $date = date("Y-m-d");

  $query = "INSERT INTO orders VALUES
              (NULL, '". $conn->real_escape_string($customerid) . "', '".
              $conn->real_escape_string($_SESSION['total_price']) . "', '".
              $conn->real_escape_string($date) ."', 'PARTIAL', '" .
              $conn->real_escape_string($ship_name) . "', '" .
              $conn->real_escape_string($ship_address) . "', '".
              $conn->real_escape_string($ship_city)."', '" .
              $conn->real_escape_string($ship_zip) . "', '".
              $conn->real_escape_string($ship_country)."')";

  $result = $conn->query($query);
  if (!$result) {
    return false;
  }

  $query = "SELECT orderid
              FROM orders
              WHERE
               customerid = '". $conn->real_escape_string($customerid)."' AND
               amount > (".(float)$_SESSION['total_price'] ."-.001) AND
               amount < (". (float)$_SESSION['total_price']."+.001) AND
               date = '".$conn->real_escape_string($date)."' AND
               order_status = 'PARTIAL' AND
               ship_name = '".$conn->real_escape_string($ship_name)."' AND
               ship_address = '".$conn->real_escape_string($ship_address)."' AND
               ship_city = '".$conn->real_escape_string($ship_city)."' AND
               ship_zip = '".$conn->real_escape_string($ship_zip)."' AND
               ship_country = '".$conn->real_escape_string($ship_country)."'";

  $result = $conn->query($query);

  if ($result->num_rows > 0) {
    $order = $result->fetch_object();
    $orderid = $order->orderid;
  } else {
    return false;
  }

  // Vkládáme jednotlivé položky (knihy).
  foreach ($_SESSION['cart'] as $isbn => $quantity) {
    $detail = get_book_details($isbn);
    $query = "DELETE FROM order_items
                WHERE
                  orderid = '". $conn->real_escape_string($orderid)."' AND
                  isbn = '". $conn->real_escape_string($isbn)."'";
    $result = $conn->query($query);
    $query = "INSERT INTO order_items VALUES
                (". $conn->real_escape_string($orderid) .", '".
                $conn->real_escape_string($isbn) . "', ".
                $conn->real_escape_string($detail['price']) .", " .
                $conn->real_escape_string($quantity). ")";
    $result = $conn->query($query);
    if (!$result) {
      return false;
    }
  }

  // Ukončujeme transakci.
  $conn->commit();
  $conn->autocommit(TRUE);

  return $orderid;
}

?>
