<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Přidání kategorie");
if (check_admin_user()) {
  if (filled_out($_POST))   {
    $catname = $_POST['catname'];
    if (insert_category($catname)) {
      echo "<p>Kategorie \"".htmlspecialchars($catname)."\" byla přidána do databáze.</p>";
    } else {
      echo "<p>Kategorii \"".htmlspecialchars($catname)."\" se nepodařilo přidat do databáze.</p>";
    }
  } else {
    echo "<p>Nevyplnil/a jste včechna pole. Prosíme, zkuste to znovu.</p>";
  }
  do_html_url('admin.php', 'Zpět k administrační nabídce');
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku.</p>";
}

do_html_footer();

?>
