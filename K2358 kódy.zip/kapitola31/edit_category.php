<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Úprava kategorie");
if (check_admin_user()) {
  if (filled_out($_POST)) {
    if (update_category($_POST['catid'], $_POST['catname'])) {
      echo "<p>Kategorie byla aktualizována.</p>";
    } else {
      echo "<p>Kategorii se nepodařilo aktualizovat.</p>";
    }
  } else {
    echo "<p>Nevyplnil/a jste včechna pole. Prosíme, zkuste to znovu.</p>";
  }
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku.</p>";
}
do_html_footer();

?>
