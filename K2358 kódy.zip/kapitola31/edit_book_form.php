<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Editace knihy");
if (check_admin_user()) {
  if ($book = get_book_details($_GET['isbn'])) {
    display_book_form($book);
  } else {
    echo "<p>Nepodařilo se načíst údaje o knize.</p>";
  }
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku.</p>";
}
do_html_footer();

?>
