<?php

// Vypisuje záhlaví stránky HTML.
function do_html_header($title = '') {
  // Definujeme relační proměnné, k nimž chceme přistupovat v této funkci.
  if (empty($_SESSION['items'])) {
    $_SESSION['items'] = '0';
  }
  if (empty($_SESSION['total_price'])) {
    $_SESSION['total_price'] = '0.00';
  }
?>
  <html>
  <head>
    <meta charset="UTF-8" />
    <title><?php echo htmlspecialchars($title); ?></title>
    <style>
      h2 { font-family: Arial, Helvetica, sans-serif; font-size: 22px; color: red; margin: 6px }
      body { font-family: Arial, Helvetica, sans-serif; font-size: 13px }
      li, td { font-family: Arial, Helvetica, sans-serif; font-size: 13px }
      hr { color: #FF0000; width=70%; text-align=center}
      a { color: #000000 }
    </style>
  </head>
  <body>
    <table width="100%" border="0" cellspacing="0" bgcolor="#cccccc">
      <tr>
        <td rowspan="2">
        <a href="index.php"><img src="images/Book-O-Rama.gif" alt="Bookorama"
            border="0" align="left" valign="bottom" height="55"
            width="325"/></a>
        </td>
        <td align="right" valign="bottom">
        <?php
          if (isset($_SESSION['admin_user'])) {
            echo "&nbsp;";
          } else {
            echo "Celkem položek = " . htmlspecialchars($_SESSION['items']);
          }
        ?>
        </td>
        <td align="right" rowspan="2" width="135">
        <?php
          if (isset($_SESSION['admin_user'])) {
            display_button('logout.php', 'log-out', 'Odhlásit se');
          } else {
            display_button('show_cart.php', 'view-cart', 'Zobrazit nákupní košík');
          }
        ?>
      </tr>
      <tr>
      <td align="right" valign="top">
      <?php
        if(isset($_SESSION['admin_user'])) {
          echo "&nbsp;";
        } else {
          echo "Celková cena = " .
            number_format($_SESSION['total_price'], 2, ",", " ") . " Kč";
        }
      ?>
      </td>
      </tr>
    </table>
<?php
  if ($title) {
    do_html_heading($title);
  }
}

// Vypisuje zápatí stránky HTML.
function do_html_footer() {
?>
  </body>
  </html>
<?php
}

// Vypisuje nadpis.
function do_html_heading($heading) {
?>
  <h2><?php echo htmlspecialchars($heading); ?></h2>
<?php
}

// Vypisuje adresu URL jako odkaz se zalomením řádku.
function do_html_URL($url, $name) {
?>
  <a href="<?php echo htmlspecialchars($url); ?>"><?php echo $name; ?></a><br />
<?php
}

function display_categories($cat_array) {
  if (!is_array($cat_array)) {
    echo "<p>Nejsou k dispozici žádné kategorie.</p>";
    return;
  }

  echo "<ul>";
  foreach ($cat_array as $row)  {
    $url = "show_cat.php?catid=".urlencode($row['catid']);
    $title = $row['catname'];
    echo "<li>";
    do_html_url($url, $title);
    echo "</li>";
  }
  echo "</ul>";
  echo "<hr />";
}

// Vypisuje všechny knihy v daném poli.
function display_books($book_array) {
  if (!is_array($book_array)) {
    echo "<p>V této kategorii nejsou moméntálně žádné knihy.</p>";
  } else {
    // Vytváříme tabulku.
    echo "<table width=\"100%\" border=\"0\">";

    // Vtyváříme řádek tabulky pro každou knihu.
    foreach ($book_array as $row) {
      $url = "show_book.php?isbn=" . urlencode($row['isbn']);
      echo "<tr><td>";
      if (@file_exists("images/{$row['isbn']}.jpg")) {
        $title = "<img src=\"images/". htmlspecialchars($row['isbn']) . ".jpg\"
                  style=\"border: 1px solid black\"/>";
        do_html_url($url, $title);
      } else {
        echo "&nbsp;";
      }
      echo "</td><td>";
      $title = htmlspecialchars($row['title']) . ", napsal " . htmlspecialchars($row['author']);
      do_html_url($url, $title);
      echo "</td></tr>";
    }

    echo "</table>";
  }

  echo "<hr />";
}

// Vypisuje všechny údaje o dané knize.
function display_book_details($book) {
  if (is_array($book)) {
    echo "<table><tr>";
    // Zobrazujeme obrázek, pokud je k dispozici.
    if (@file_exists("images/{$book['isbn']}.jpg"))  {
      $size = GetImageSize("images/{$book['isbn']}.jpg");
      if (($size[0] > 0) && ($size[1] > 0)) {
        echo "<td><img src=\"images/".htmlspecialchars($book['isbn']).".jpg\"
              style=\"border: 1px solid black\"/></td>";
      }
    }
    echo "<td><ul>";
    echo "<li><strong>Autor:</strong> ";
    echo htmlspecialchars($book['author']);
    echo "</li><li><strong>ISBN:</strong> ";
    echo htmlspecialchars($book['isbn']);
    echo "</li><li><strong>Naše cena:</strong> ";
    echo number_format($book['price'], 2, ",", " ");
    echo "</li><li><strong>Popis:</strong> ";
    echo htmlspecialchars($book['description']);
    echo "</li></ul></td></tr></table>";
  } else {
    echo "<p>Údaje o této knize není možné v současnosti zobrazit.</p>";
  }
  echo "<hr />";
}

// Zobrazuje formulář, který žádá jméno a adresu.
function display_checkout_form() {
?>
  <br />
  <table border="0" width="100%" cellspacing="0">
  <form action="purchase.php" method="post">
  <tr><th colspan="2" bgcolor="#cccccc">Vaše údaje</th></tr>
  <tr>
    <td>Jméno</td>
    <td><input type="text" name="name" value="" maxlength="40" size="40"/></td>
  </tr>
  <tr>
    <td>Adresa</td>
    <td><input type="text" name="address" value="" maxlength="40" size="40"/></td>
  </tr>
  <tr>
    <td>Obec</td>
    <td><input type="text" name="city" value="" maxlength="20" size="40"/></td>
  </tr>
  <tr>
    <td>PSČ</td>
    <td><input type="text" name="zip" value="" maxlength="10" size="40"/></td>
  </tr>
  <tr>
    <td>Země</td>
    <td><input type="text" name="country" value="" maxlength="20" size="40"/></td>
  </tr>
  <tr><th colspan="2" bgcolor="#cccccc">Doručovací adresa (ponechejte prázdnou, shoduje-li se s výše uvedenou)</th></tr>
  <tr>
    <td>Jméno</td>
    <td><input type="text" name="ship_name" value="" maxlength="40" size="40"/></td>
  </tr>
  <tr>
    <td>Adresa</td>
    <td><input type="text" name="ship_address" value="" maxlength="40" size="40"/></td>
  </tr>
  <tr>
    <td>Obec</td>
    <td><input type="text" name="ship_city" value="" maxlength="20" size="40"/></td>
  </tr>
  <tr>
    <td>PSČ</td>
    <td><input type="text" name="ship_zip" value="" maxlength="10" size="40"/></td>
  </tr>
  <tr>
    <td>Země</td>
    <td><input type="text" name="ship_country" value="" maxlength="20" size="40"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><p><strong>Prosíme, stiskněte tlačítko
      "Objednat" pro dokončení vašeho nákupu nebo tlačítko "Dále nakupovat" pro přidání nebo odebrání položek.</strong></p>
      <?php display_form_button("purchase", "Objednat tyto položky"); ?>
    </td>
  </tr>
  </form>
  </table><hr />
<?php
}

// Zobrazuje řádek s cenou dopravy a celkovou cenou včetně dopravy.
function display_shipping($shipping) {
?>
  <table border="0" width="100%" cellspacing="0">
  <tr>
    <td align="left">Doprava</td>
    <td align="right"> <?php echo number_format($shipping, 2, ",", " "); ?></td>
  </tr>
  <tr>
    <th bgcolor="#cccccc" align="left">CELKOVÁ CENA S DOPRAVOU</th>
    <th bgcolor="#cccccc" align="right"><?php echo number_format($shipping + $_SESSION['total_price'], 2, ",", " "); ?> Kč</th>
  </tr>
  </table><br />
<?php
}

// Zobrazuje formulář pro zadání údajů o platební kartě.
function display_card_form($name) {
?>
  <table border="0" width="100%" cellspacing="0">
  <form action="process.php" method="post">
  <tr><th colspan="2" bgcolor="#cccccc">Údaje o platební kartě</th></tr>
  <tr>
    <td>Typ</td>
    <td><select name="card_type">
      <option value="VISA">VISA</option>
      <option value="MasterCard">MasterCard</option>
      <option value="American Express">American Express</option>
      </select>
    </td>
  </tr>
  <tr>
    <td>Číslo</td>
    <td><input type="text" name="card_number" value="" maxlength="16" size="40"></td>
  </tr>
  <tr>
    <td>CCV (je-li nutné)</td>
    <td><input type="text" name="ccv_code" value="" maxlength="3" size="3"></td>
  </tr>
  <tr>
    <td>Datum expirace</td>
    <td>Měsíc
      <select name="card_month">
        <option value="01">01</option>
        <option value="02">02</option>
        <option value="03">03</option>
        <option value="04">04</option>
        <option value="05">05</option>
        <option value="06">06</option>
        <option value="07">07</option>
        <option value="08">08</option>
        <option value="09">09</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
      </select>
      Rok
      <select name="card_year">
      <?php
        for ($y = date("Y"); $y < date("Y") + 10; $y++) {
          echo "<option value=\"".$y."\">".$y."</option>";
        }
      ?>
      </select>
  </tr>
  <tr>
    <td>Jméno vlastníka karty</td>
    <td><input type="text" name="card_name" value = "<?php echo $name; ?>" maxlength="40" size="40"></td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <p><strong>Prosíme, stiskněte tlačítko Objednat pro dokončení vašeho
      nákupu nebo tlačítko Pokračovat v nakupování pro přidání nebo
      odebrání položek.</strong></p>
      <?php display_form_button('purchase', 'Objednat tyto položky'); ?>
    </td>
  </tr>
  </table>
<?php
}

// Zobrazuje položky v nákupním košíku. Volitelně umožňuje změny (true nebo
// false) a vkládat obrázky (1 = ano, 0 = ne).
function display_cart($cart, $change = true, $images = 1) {
  echo "<table border=\"0\" width=\"100%\" cellspacing=\"0\">
          <form action=\"show_cart.php\" method=\"post\">
          <tr>
            <th colspan=\"".(1 + $images)."\" bgcolor=\"#cccccc\">Položka</th>
            <th bgcolor=\"#cccccc\">Cena</th>
            <th bgcolor=\"#cccccc\">Množství</th>
            <th bgcolor=\"#cccccc\">Celkem</th>
          </tr>";

  // Zobrazujeme jednotlivé položky jako řádky tabulky.
  foreach ($cart as $isbn => $qty)  {
    $book = get_book_details($isbn);
    echo "<tr>";
    if ($images == true) {
      echo "<td align=\"left\">";
      if (file_exists("images/{$isbn}.jpg")) {
        $size = GetImageSize("images/{$isbn}.jpg");
        if (($size[0] > 0) && ($size[1] > 0)) {
          echo "<img src=\"images/".htmlspecialchars($isbn).".jpg\"
                  style=\"border: 1px solid black\"
                  width=\"".($size[0]/3)."\"
                  height=\"".($size[1]/3)."\"/>";
         }
      } else {
        echo "&nbsp;";
      }
      echo "</td>";
    }
    echo "<td align=\"left\">
            <a href=\"show_book.php?isbn=".urlencode($isbn)."\">".
              htmlspecialchars($book['title'])."</a>,
            napsal ".htmlspecialchars($book['author'])."
          </td>
          <td align=\"center\">".number_format($book['price'], 2, ",", " ")." Kč</td>
          <td align=\"center\">";

    // Pokud jsme povolili změny, zobrazíme množství v textových polích.
    if ($change == true) {
      echo "<input type=\"text\" name=\"".htmlspecialchars($isbn)."\" value=\"".htmlspecialchars($qty)."\" size=\"3\">";
    } else {
      echo $qty;
    }
    echo "</td><td align=\"center\">".number_format($book['price'] * $qty, 2, ",", " ")." Kč</td></tr>\n";
  }
  // Zobrazujeme řádek se součty.
  echo "<tr>
          <th colspan=\"".(2+$images)."\" bgcolor=\"#cccccc\">&nbsp;</td>
          <th align=\"center\" bgcolor=\"#cccccc\">".htmlspecialchars($_SESSION['items'])."</th>
          <th align=\"center\" bgcolor=\"#cccccc\">
            ".number_format($_SESSION['total_price'], 2, ",", " ")." Kč
          </th>
        </tr>";

  // Zobrazujeme tlačítko pro ukládání změn.
  if ($change == true) {
    echo "<tr>
            <td colspan=\"".(2+$images)."\">&nbsp;</td>
            <td align=\"center\">
              <input type=\"hidden\" name=\"save\" value=\"true\"/>
              <input type=\"image\" src=\"images/save-changes.gif\"
                border=\"0\" alt=\"Uložit změny\"/>
            </td>
            <td>&nbsp;</td>
          </tr>";
  }
  echo "</form></table>";
}

// Zobrazuje formulář pro zadání jména a hesla.
function display_login_form() {
?>
  <form method="post" action="admin.php">
  <table bgcolor="#cccccc">
    <tr>
      <td>Uživatelské jméno:</td>
      <td><input type="text" name="username"/></td></tr>
    <tr>
      <td>Heslo:</td>
      <td><input type="password" name="passwd"/></td></tr>
    <tr>
      <td colspan="2" align="center">
      <input type="submit" value="Přihlásit se"/></td></tr>
    <tr>
  </table></form>
<?php
}

function display_admin_menu() {
?>
  <br />
  <a href="index.php">Hlavní stránka</a><br />
  <a href="insert_category_form.php">Přidat novou kategorii</a><br />
  <a href="insert_book_form.php">Přidat novou knihu</a><br />
  <a href="change_password_form.php">Změnit heslo správce</a><br />
<?php
}

function display_button($target, $image, $alt) {
  echo "<div align=\"center\">
          <a href=\"".htmlspecialchars($target)."\">
            <img src=\"images/".htmlspecialchars($image).".gif\"
              alt=\"".htmlspecialchars($alt)."\" border=\"0\" height=\"50\"
              width=\"135\"/>
          </a>
        </div>";
}

function display_form_button($image, $alt) {
  echo "<div align=\"center\">
          <input type=\"image\"
            src=\"images/".htmlspecialchars($image).".gif\"
            alt=\"".htmlspecialchars($alt)."\" border=\"0\" height=\"50\"
            width=\"135\"/>
        </div>";
}

?>
