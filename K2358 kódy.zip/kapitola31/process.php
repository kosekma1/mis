<?php
  include ('book_sc_fns.php');
  // Nákupní košík potřebuje relaci, proto jednu spouštíme.
  session_start();

  do_html_header('Pokladna');

  $card_type = $_POST['card_type'];
  $card_number = $_POST['card_number'];
  $card_month = $_POST['card_month'];
  $card_year = $_POST['card_year'];
  $card_name = $_POST['card_name'];

  if (($_SESSION['cart']) && ($card_type) && ($card_number) &&
      ($card_month) && ($card_year) && ($card_name)) {
    // Zobrazíme košík, v němž neumožníme dělat změny a vypustíme obrázky.
    display_cart($_SESSION['cart'], false, 0);

    display_shipping(calculate_shipping_cost());

    if (process_card($_POST)) {
      // Vyprázdníme nákupní košík.
      session_destroy();
      echo "<p>Děkujeme, že jste nakupovali u nás. Vaše objednávka bude brzy vyřízena.</p>";
      display_button("index.php", "continue-shopping", "Dále nakupovat");
    } else {
      echo "<p>Nepodařilo se zpracovat vaši platební kartu. Prosíme, kontaktujte vydavatele své karty nebo to zkuste znovu.</p>";
      display_button("purchase.php", "back", "Zpět");
    }
  } else {
    echo "<p>Nevyplnil/a jste včechna pole. Prosíme, zkuste to znovu.</p><hr />";
    display_button("purchase.php", "back", "Zpět");
  }

  do_html_footer();
?>
