<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Přidání knihy");
if (check_admin_user()) {
  display_book_form();
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a vstoupit do administrační oblasti.</p>";
}
do_html_footer();

?>
