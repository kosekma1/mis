<?php

// Posíláme naše produkty po celém světě teleportací, takže máme pevnou cenu.
function calculate_shipping_cost() {
  return 500;
}

// Dotazuje se databáze na seznam kategorií.
function get_categories() {
  $conn = db_connect();
  $query = "SELECT catid, catname FROM categories";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  }
  $num_cats = @$result->num_rows;
  if ($num_cats == 0) {
    return false;
  }
  $result = db_result_to_array($result);
  return $result;
}

// Dotazuje se databáze na název kategorie s daným identifikátorem.
function get_category_name($catid) {
  $conn = db_connect();
  $query = "SELECT catname
              FROM categories
              WHERE catid = '".$conn->real_escape_string($catid)."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  }
  $num_cats = @$result->num_rows;
  if ($num_cats == 0) {
    return false;
  }
  $row = $result->fetch_object();
  return $row->catname;
}

// Dotazuje se databáze na knihy v kategorii.
function get_books($catid) {
  if ((!$catid) || ($catid == '')) {
    return false;
  }

  $conn = db_connect();
  $query = "SELECT *
              FROM books
              WHERE catid = '".$conn->real_escape_string($catid)."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  }
  $num_books = @$result->num_rows;
  if ($num_books == 0) {
    return false;
  }
  $result = db_result_to_array($result);
  return $result;
}

// Dotazuje se databáze na všechny údaje o konkrétní knize.
function get_book_details($isbn) {
  if ((!$isbn) || ($isbn=='')) {
    return false;
  }
  $conn = db_connect();
  $query = "SELECT *
              FROM books
              WHERE isbn='".$conn->real_escape_string($isbn)."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  }
  $result = @$result->fetch_assoc();
  return $result;
}

// Počítá celkovou cenu pro všechny položky v nákupním košíku.
function calculate_price($cart) {
  $price = 0.0;
  if (is_array($cart)) {
    $conn = db_connect();
    foreach ($cart as $isbn => $qty) {
      $query = "SELECT price
                  FROM books
                  WHERE isbn='".$conn->real_escape_string($isbn)."'";
      $result = $conn->query($query);
      if ($result) {
        $item = $result->fetch_object();
        $item_price = $item->price;
        $price +=$item_price * $qty;
      }
    }
  }
  return $price;
}

// Určuje celkový počet položek v nákupním košíku.
function calculate_items($cart) {
  $items = 0;
  if (is_array($cart)) {
    foreach ($cart as $isbn => $qty) {
      $items += $qty;
    }
  }
  return $items;
}
?>
