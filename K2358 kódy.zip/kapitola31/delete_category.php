<?php

require_once('book_sc_fns.php');
session_start();

do_html_header("Mazání kategorie");
if (check_admin_user()) {
  if (isset($_POST['catid'])) {
    if (delete_category($_POST['catid'])) {
      echo "<p>Kategorie byla smazána.</p>";
    } else {
      echo "<p>Kategorii se nepodařilo smazat.<br />
            Obvykle se to stává, pokud kategorie není prázdná.</p>";
    }
  } else {
    echo "<p>Neuvedl/a jste žádnou kategorii. Prosíme, zkuste to znovu.</p>";
  }
  do_html_url("admin.php", "Zpět k administrační nabídce");
} else {
  echo "<p>Nejste oprávněn/a prohlížet si tuto stránku</p>";
}
do_html_footer();

?>
