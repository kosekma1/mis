<?php
// Tento soubor obsahuje funkce pro administrační rozhraní internetového
// obchodu Book-O-Rama.

// Zobrazuje formulář kategorie. Tento formulář slouží pro vkládání
// a editaci kategorií. Při vkládání nepředáváme této funkci žádné
// argumenty. Tak přidělíme proměnné $edit hodnotu false a formulář
// bude směřovat na skript insert_category.php. Při editaci předáváme
// této funkci pole s kategorií. Formulář bude obsahovat původní data
// a bude směřovat na skript update_category.php. Navíc v něm přibude
// tlačítko "Smazat kategorii".
function display_category_form($category = '') {

  // Jestliže jsme předali existující kategorii, budeme pokračovat v režimu
  // editace.
  $edit = is_array($category);

  // Většinu tohoto formuláře tvoří kód HTML s doplňkovými částmi kódu PHP.
?>
  <form method="post"
        action="<?php echo $edit ? 'edit_category.php' : 'insert_category.php'; ?>">
  <table border="0">
  <tr>
    <td>Název kategorie:</td>
    <td><input type="text" name="catname" size="40" maxlength="40"
          value="<?php echo htmlspecialchars($edit ? $category['catname'] : ''); ?>" /></td>
   </tr>
  <tr>
    <td <?php if (!$edit) { echo "colspan=2";} ?> align="center">
      <?php
        if ($edit) {
          echo "<input type=\"hidden\" name=\"catid\" value=\"". htmlspecialchars($category['catid'])."\" />";
        }
      ?>
      <input type="submit"
        value="<?php echo $edit ? 'Upravit' : 'Přidat'; ?> kategorii" />
    </form>
    </td>
    <?php
      if ($edit) {
        // Umožňuje smazat existující kategorii.
        echo "<td>
                <form method=\"post\" action=\"delete_category.php\" style=\"display: inline\">
                  <input type=\"hidden\" name=\"catid\" value=\"". htmlspecialchars($category['catid'])."\" />
                  <input type=\"submit\" value=\"Smazat kategorii\" />
                </form>
              </td>";
      }
    ?>
  </tr>
  </table>
<?php
}

// Tato funkce zobrazuje formulář knihy. Úzce se podobá formuláři kategorie.
// Tento formulář není možné použít na vkládání nebo editaci knih. Při vkládání
// nepředáváme této funkci žádné argumenty. Tak přidělíme proměnné $edit
// hodnotu false a formulář bude směřovat na skript insert_book.php. Při
// editaci předáváme této funkci pole s knihou. Formulář bude obsahovat původní
// data a bude směřovat na skript update_book.php. Navíc v něm přibude
// tlačítko "Smazat knihu".
function display_book_form($book = '') {

  // Jestliže jsme předali existující knihu, budeme pokračovat v režimu editace.
  $edit = is_array($book);

  // Většinu tohoto formuláře tvoří kód HTML s doplňkovými částmi kódu PHP.
?>
  <form method="post"
        action="<?php echo $edit ? 'edit_book.php' : 'insert_book.php';?>">
  <table border="0">
  <tr>
    <td>ISBN:</td>
    <td><input type="text" name="isbn"
          value="<?php echo htmlspecialchars($edit ? $book['isbn'] : ''); ?>" /></td>
  </tr>
  <tr>
    <td>Název knihy:</td>
    <td><input type="text" name="title"
          value="<?php echo htmlspecialchars($edit ? $book['title'] : ''); ?>" /></td>
  </tr>
  <tr>
    <td>Autor knihy:</td>
    <td><input type="text" name="author"
          value="<?php echo htmlspecialchars($edit ? $book['author'] : ''); ?>" /></td>
  </tr>
  <tr>
    <td>Kategorie:</td>
    <td>
      <select name="catid">
      <?php
        // Seznam možných kategorií z databáze.
        $cat_array = get_categories();
        foreach ($cat_array as $thiscat) {
          echo "<option value=\"".htmlspecialchars($thiscat['catid'])."\"";
          // Pokud se jedná o existující knihu, vybereme její aktuální kategorii.
          if (($edit) && ($thiscat['catid'] == $book['catid'])) {
            echo " selected";
          }
          echo ">".htmlspecialchars($thiscat['catname'])."</option>";
        }
      ?>
      </select>
    </td>
  </tr>
  <tr>
    <td>Cena:</td>
    <td><input type="text" name="price"
          value="<?php echo htmlspecialchars($edit ? $book['price'] : ''); ?>" /></td>
  </tr>
  <tr>
    <td>Popis:</td>
    <td><textarea rows="3" cols="50"
          name="description"><?php echo htmlspecialchars($edit ? $book['description'] : ''); ?></textarea></td>
  </tr>
  <tr>
    <td <?php if (!$edit) { echo "colspan=2"; }?> align="center">
      <?php
      if ($edit)
        // Potřebuje původní kód ISBN, abychom našli knihu v databázi,
        // jestliže ji upravujeme.
        echo "<input type=\"hidden\" name=\"oldisbn\"
                value=\"".htmlspecialchars($book['isbn'])."\" />";
      ?>
      <input type="submit"
        value="<?php echo $edit ? 'Upravit' : 'Přidat'; ?> knihu" />
    </form>
    </td>
    <?php
      if ($edit) {
        echo "
          <td>
            <form method=\"post\" action=\"delete_book.php\" style=\"display: inline\">
              <input type=\"hidden\" name=\"isbn\" value=\"".htmlspecialchars($book['isbn'])."\" />
              <input type=\"submit\" value=\"Smazat knihu\"/>
            </form>
          </td>";
      }
    ?>
  </tr>
  </table>
<?php
}

// Zobrazuje formulář HTML pro změnu hesla.
function display_password_form() {
?>
  <br />
  <form action="change_password.php" method="post">
  <table width="250" cellpadding="2" cellspacing="0" bgcolor="#cccccc">
  <tr>
    <td>Původní heslo:</td>
    <td><input type="password" name="old_passwd" size="16" maxlength="16" /></td>
  </tr>
  <tr>
    <td>Nové heslo:</td>
    <td><input type="password" name="new_passwd" size="16" maxlength="16" /></td>
  </tr>
  <tr>
    <td>Potvrzení nového hesla:</td>
    <td><input type="password" name="new_passwd2" size="16" maxlength="16" /></td>
  </tr>
  <tr>
    <td colspan=2 align="center"><input type="submit" value="Změnit heslo"></td>
  </tr>
  </table>
  </form>
  <br />
<?php
}

// Vkládá novou kategorii do databáze.
function insert_category($catname) {

  $conn = db_connect();

  // Ověřujeme, jestli kategorie už neexistuje.
  $query = "SELECT *
              FROM categories
              WHERE catname='".$conn->real_escape_string($catname)."'";
  $result = $conn->query($query);
  if ((!$result) || ($result->num_rows != 0)) {
    return false;
  }

  // Vkládáme novou kategorii.
  $query = "INSERT INTO categories VALUES
              (NULL, '".$conn->real_escape_string($catname)."')";
  $result = $conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

// Vkládá novou knihu do databáze.
function insert_book($isbn, $title, $author, $catid, $price, $description) {

  $conn = db_connect();

  // Ověřujeme, jestli kniha už neexistuje.
  $query = "SELECT *
              FROM books
              WHERE isbn='".$conn->real_escape_string($isbn)."'";

  $result = $conn->query($query);
  if ((!$result) || ($result->num_rows != 0)) {
    return false;
  }

  // Vkládáme novou knihu.
  $query = "INSERT INTO books VALUES
              ('".$conn->real_escape_string($isbn) ."', '".
              $conn->real_escape_string($author) . "', '".
              $conn->real_escape_string($title) ."', '".
              $conn->real_escape_string($catid) . "', '".
              $conn->real_escape_string($price) ."', '" .
              $conn->real_escape_string($description) ."')";
  $result = $conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

// Mění název kategorie s daným identifikátorem.
function update_category($catid, $catname) {

  $conn = db_connect();

  $query = "UPDATE categories
              SET catname='".$conn->real_escape_string($catname) ."'
              WHERE catid='".$conn->real_escape_string($catid) ."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

// Mění údaje o knize uložené pod daným kódem ISBN.
function update_book($oldisbn, $isbn, $title, $author, $catid,
                     $price, $description) {

  $conn = db_connect();

  $query = "UPDATE books
              SET isbn= '".$conn->real_escape_string($isbn)."',
                title = '".$conn->real_escape_string($title)."',
                author = '".$conn->real_escape_string($author)."',
                catid = '".$conn->real_escape_string($catid)."',
                price = '".$conn->real_escape_string($price)."',
                description = '".$conn->real_escape_string($description)."'
                where isbn = '".$conn->real_escape_string($oldisbn)."'";

  $result = @$conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

// Odstraňuje kategorii s daným identifikátorem z databáze. Pokud tato
// kategorie obsahuje nějaké knihy, nebude odstraněna a tato funkce vrátí
// hodnotu false.
function delete_category($catid) {

  $conn = db_connect();

  // Ověřujeme, zda tato kategorie obsahuje nějaké knihy, abychom se vyhnuli
  // anomáliím při mazání.
  $query = "SELECT *
              FROM books
              WHERE catid='".$conn->real_escape_string($catid)."'";

  $result = @$conn->query($query);
  if ((!$result) || (@$result->num_rows > 0)) {
    return false;
  }

  $query = "DELETE FROM categories
              WHERE catid='".$conn->real_escape_string($catid)."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

// Maže knihu s daným kódem ISBN z databáze.
function delete_book($isbn) {

  $conn = db_connect();

  $query = "DELETE FROM books
              WHERE isbn='".$conn->real_escape_string($isbn)."'";
  $result = @$conn->query($query);
  if (!$result) {
    return false;
  } else {
    return true;
  }
}

?>
