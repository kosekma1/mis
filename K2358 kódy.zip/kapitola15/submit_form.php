<?php
switch ($_POST['gender']) {
  case 'muž':
  case 'žena':
  case 'jiné':

    echo "<h1>Gratuluji!<br/>
         Jste: ".$_POST['gender']. ".</h1>";
    break;

  default:

    echo "<h1><span style=\"color:  red;\">VAROVÁNÍ:</span><br/>
         Neplatná vstupní hodnota.</h1>";
  break;
}
?>
