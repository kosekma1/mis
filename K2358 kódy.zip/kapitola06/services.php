<?php
  require ("page.php");

  class ServicesPage extends Page {
    private $row2buttons = array(
                             "Reinženýring" => "reengineering.php",
                             "Standardizace" => "standards.php",
                             "Buzzwordy" => "buzzword.php",
                             "Mise" => "mission.php"
                           );

    public function display() {
      echo "<html>\n<head>\n";
      $this->displayTitle();
      $this->displayKeywords();
      $this->displayStyles();
      echo "</head>\n<body>\n";
      $this->displayHeader();
      $this->displayMenu($this->buttons);
      $this->displayMenu($this->row2buttons);
      echo $this->content;
      $this->displayFooter();
      echo "</body>\n</html>\n";
    }
  }

  $services = new ServicesPage();

  $services->content = "<p>V naší společnosti TLA Consulting nabízíme
  celou řadu služeb. Produktivita vašich zaměstnanců by pravděpodobně
  vzrostla, kdybychom provedli reinženýring vašeho byznysu. Možná vaše
  podnikání potřebuje novou misi nebo novou dávku buzzwordů.</p>";

  $services->display();
?>
