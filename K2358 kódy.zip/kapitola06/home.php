<?php
  require("page.php");

  $homepage = new Page();

  $homepage->content = "<!-- obsah stránky -->
                        <section>
                          <h2>Vítejte na stránkách společnosti TLA
                            Consulting.</h2>
                          <p>Prosíme, věnujte chvilku času, abyste nás
                            poznali.</p>
                          <p>Rádi vám pomůžeme s vaším podnikáním. Kontaktujte
                            nás.</p>
                        </section>";
  $homepage->display();
?>
