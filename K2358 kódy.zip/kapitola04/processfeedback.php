<?php

// vytváříme zkrácené názvy proměnných
$name = $_POST['name'];
$email = $_POST['email'];
$feedback = $_POST['feedback'];

// připravujeme statické informace
$toaddress = "feedback@priklad.cz";

$subject = "Zpětná vazba z webových stránek";

$mailcontent = "Jméno zákazníka: ".filter_var($name)."\n".
               "E-mail zákazníka: ".$email."\n".
               "Komentář zákazníka:\n".$feedback."\n";

$fromaddress = "From: webserver@priklad.cz";

// odesíláme e-mail funkcí mail()
mail($toaddress, $subject, $mailcontent, $fromaddress);

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Bobovy autodíly – Zpětná vazba odeslána</title>
  </head>
  <body>

    <h1>Zpětná vazba odeslána</h1>
    <p>Vaše zpětná vazba byla úspěšně odeslána.</p>

  </body>
</html>
