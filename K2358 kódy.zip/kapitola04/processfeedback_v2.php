<?php

// vytváříme zkrácené názvy proměnných
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$feedback = trim($_POST['feedback']);

//set up some static information
$toaddress = "feedback@priklad.cz";

$subject = "Zpětná vazba z webových stránek";

$mailcontent = "Jméno zákazníka: ".str_replace("\r\n", "", $name)."\n".
               "E-mail zákazníka: ".str_replace("\r\n", "", $email)."\n".
               "Komentář zákazníka:\n".str_replace("\r\n", "", $feedback)."\n";

$fromaddress = "From: webserver@priklad.cz";

// odesíláme e-mail funkcí mail()
mail($toaddress, $subject, $mailcontent, $fromaddress);

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Bobovy autodíly – Zpětná vazba odeslána</title>
  </head>
  <body>

    <h1>Zpětná vazba odeslána</h1>
    <p>Vaše zpětná vazba byla úspěšně odeslána.</p>
    <p><?php echo nl2br(htmlspecialchars($mailcontent)); ?> </p>
  </body>
</html>
