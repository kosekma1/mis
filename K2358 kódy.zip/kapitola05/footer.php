  <!-- zápatí stránky -->
  <footer>
    <p>&copy; TLA Consulting, a.s.<br />
      Prohlédněte si naši
      <a href="legal.php">stránku s právními informacemi</a>.</p>
  </footer>

</body>
</html>
