<?php
function fn() {
  echo 'uvnitř funkce nejprve platí, že $var = '.$var.'<br />';
  $var = 2;
  echo 'a později uvnitř ní platí, že $var = '.$var.'<br />';
}
$var = 1;
fn();
echo 'vně funkce platí, že $var = '.$var.'<br />';
?>
