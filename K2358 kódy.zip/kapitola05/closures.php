<?php

$printer =  function($value) { echo "$value <br/>"; };

$products = [ 'Pneumatiky' => 2500,
              'Lahve oleje' => 250,
              'Zapalovací svíčky' => 100 ];

$markup = 0.21;

$apply = function(&$val) use ($markup) {
  $val = $val * (1 + $markup);
};

array_walk($products, $apply);

array_walk($products, $printer);

?>