<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Tvorba tabulky</title>
    <style type="text/css">
      caption {
        font-style: italic;
        padding-bottom: 6px;
      }

      table, tr, td, th {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 3px;
      }
    </style>
  </head>
  <body>
  <?php
    function create_table($data, $header = NULL, $caption = NULL) {
      echo '<table>';
      if ($caption) {
        echo "<caption>$caption</caption>";
      }
      if ($header) {
        echo "<tr><th>$header</th></tr>";
      }
      reset($data);
      $value = current($data);
      while ($value) {
        echo "<tr><td>$value</td></tr>\n";
        $value = next($data);
      }
      echo '</table>';
    }

    $my_data = ['První kus dat', 'Druhý kus dat', 'A třetí'];
    $my_header = 'Data';
    $my_caption = 'Data o něčem';
    create_table($my_data, $my_header, $my_caption);
  ?>
  </body>
</html>
