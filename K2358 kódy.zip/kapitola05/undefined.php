<?php
  nazev_funkce();
?>
