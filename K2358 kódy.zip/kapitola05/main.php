<?php
  echo 'Toto je hlavní soubor.<br />';
  require('reusable.php');
  echo 'Tento skript teď skončí.<br />';
?>
