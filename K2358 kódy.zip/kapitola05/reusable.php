<?php
  echo 'Zde je velmi jednoduchý příkaz jazyka PHP.<br />';
?>
