<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Tvorba tabulky</title>
    <style type="text/css">
      table, tr, td {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 3px;
      }
    </style>
  </head>
  <body>
  <?php
    function create_table($data) {
      echo '<table>';
      reset($data);
      $value = current($data);
      while ($value) {
        echo "<tr><td>$value</td></tr>\n";
        $value = next($data);
      }
      echo '</table>';
    }
    
    $my_data = ['První kus dat', 'Druhý kus dat', 'A třetí'];
    create_table($my_data);
  ?>
  </body>
</html>
