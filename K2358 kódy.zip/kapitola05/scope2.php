<?php
function fn() {
  global $var;
  $var = 'obsah';
  echo 'uvnitř funkce platí, že $var = '.$var.'<br />';
}

fn();
echo 'vně funkce platí, že $var = '.$var;
?>
