<?php

function var_args() {
  echo 'Počet parametrů:';
  echo func_num_args();

  echo '<br />';
  $args = func_get_args();
  foreach ($args as $arg) {
    echo $arg.'<br />';
  }
}

var_args(1,2,3);

var_args('ahoj', 47.3);

?>
