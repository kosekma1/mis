# Základní příklad uložené funkce

DELIMITER //

CREATE FUNCTION Add_Tax (Price FLOAT) RETURNS FLOAT NO SQL
  RETURN Price*1.2;

//

DELIMITER ;
