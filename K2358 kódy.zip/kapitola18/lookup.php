<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Cena akcie indexu NASDAQ</title>
</head>
<body>

<?php
// Vybereme akcii.
$symbol = 'GOOG';
echo '<h1>Cena akcie se symbolem '.$symbol.'</h1>';

$url = 'http://download.finance.yahoo.com/d/quotes.csv' .
       '?s='.$symbol.'&e=.csv&f=sl1d1t1c1ohgv';

if (!($contents = file_get_contents($url))) {
  die('Nepodařilo se otevřít '.$url);
}

// Extrahujeme relevantní data.
list($symbol, $quote, $date, $time) = explode(',', $contents);
$date = trim($date, '"');
$time = trim($time, '"');

echo '<p>'.$symbol.' se prodává za $'.$quote.'.</p>';
echo '<p>Aktuální cena ze dne '.$date.' v '.$time.'.</p>';

// Přiznáme zdroj.
echo '<p>Tato informace pochází z <br /><a href="'.$url.'">'.$url.'</a>.</p>';

?>
</body>
</html>
