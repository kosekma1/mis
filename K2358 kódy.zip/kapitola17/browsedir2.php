<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Prohlížení adresářů</title>
</head>
<body>
  <h1>Prohlížení</h1>

<?php
  $dir = dir('/cesta/k/adresari/uploads/');

  echo '<p>Ukazatelem je ' . $dir->handle . '</p>';
  echo '<p>Adresářem pro upload je ' . $dir->path . '</p>';
  echo '<p>Výpis adresáře:</p><ul>';
  
  while (false !== ($file = $dir->read())) {
    // vynecháme položky . a ..
    if ($file != "." && $file != "..") {
      echo '<li>'.$file.'</li>';
    }
  }

  echo '</ul>';
  $dir->close();
?>

</body>
</html>
