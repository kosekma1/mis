<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Uploadování...</title>
</head>
<body>
  <h1>Uploadování souboru...</h1>

<?php

  if ($_FILES['the_file']['error'] > 0) {
    echo 'Chyba: ';
    switch ($_FILES['the_file']['error']) {
      case 1:
         echo 'Soubor je větší než upload_max_filesize.';
         break;
      case 2:
         echo 'Soubor je větší než max_file_size.';
         break;
      case 3:
         echo 'Soubor se podařilo uploadovat jen částečně.';
         break;
      case 4:
         echo 'Žádný soubor nebyl uploadován.';
         break;
      case 6:
         echo 'Nelze uploadovat soubor: není definován dočasný adresář.';
         break;
      case 7:
         echo 'Upload selhal: nelze zapisovat na disk.';
         break;
    }
    exit;
  }

  // Má tento soubor správný typ MIME?
  if ($_FILES['the_file']['type'] != 'image/png') {
    echo 'Chyba: soubor není obrázkem PNG.';
    exit;
  }

  // Uložíme soubor tam, kde bychom ho chtěli mít.
  $uploaded_file = '/cesta/k/adresari/uploads/'.$_FILES['the_file']['name'];

  if (is_uploaded_file($_FILES['the_file']['tmp_name'])) {
    if (!move_uploaded_file($_FILES['the_file']['tmp_name'], $uploaded_file)) {
      echo 'Chyba: nelze přesunout soubor do cílového adresáře.';
      exit;
    }
  } else {
    echo 'Chyba: možný útok uploadem souboru. Název souboru: ';
    echo $_FILES['the_file']['name'];
    exit;
  }

  echo 'Soubor byl úspěšně uploadován.';

  // Zobrazíme, co bylo uploadováno.
  echo '<p>Uploadovali jste následující obrázek:<br/>';
  echo '<img src="/uploads/'.$_FILES['the_file']['name'].'"/>';
?>
</body>
</html>
