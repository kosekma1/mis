<?php

chdir('/cesta/k/adresari/uploads/');

// Verze s funkcí exec()
echo '<h1>Funkce exec()</h1>';
echo '<pre>';

// Unix
// exec('ls -la', $result);

// Windows
exec('dir', $result);

foreach ($result as $line) {
  echo $line.PHP_EOL;
}

echo '</pre>';
echo '<hr />';

// Verze s funkcí passthru()
echo '<h1>Funkce passthru()</h1>';
echo '<pre>';

// Unix
// passthru('ls -la') ;

// Windows
passthru('dir');

echo '</pre>';
echo '<hr />';

// Verze s funkcí system()
echo '<h1>Funkce system()</h1>';
echo '<pre>';

// Unix
// $result = system('ls -la');

// Windows
$result = system('dir');

echo '</pre>';
echo '<hr />';

// Verze se zpětnými apostrofy
echo '<h1>Zpětné apostrofy</h1>';
echo '<pre>';

// Unix
// $result = `ls -al`;

// Windows 
$result = `dir`;

echo $result;
echo '</pre>';

?>
