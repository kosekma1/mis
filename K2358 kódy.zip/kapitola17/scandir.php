<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Prohlížení adresářů</title>
</head>
<body>
  <h1>Prohlížení</h1>

<?php
$dir = '/cesta/k/adresari/uploads/';
$files1 = scandir($dir);
$files2 = scandir($dir, 1);

echo '<p>Adresářem pro upload je ' . $dir . '</p>';
echo '<p>Výpis adresáře seřazený abecedně, a to vzestupně:</p><ul>';

foreach($files1 as $file) {
  if ($file != "." && $file != "..") {
    echo '<li>'.$file.'</li>';
  }
}

echo '</ul>';

echo '<p>Adresářem pro upload je ' . $dir . '</p>';
echo '<p>Výpis adresáře seřazený abecedně, a to sestupně:</p><ul>';

foreach($files2 as $file) {
  if ($file != "." && $file != "..") {
    echo '<li>'.$file.'</li>';
  }
}

echo '</ul>';

?>
</body>
</html>
