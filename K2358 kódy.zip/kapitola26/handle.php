<?php
// Obsluhující funkce chyb.
function my_error_handler($errtype, $errmsg, $errfile, $errline) {
  echo "<p><strong>CHYBA:</strong> ".$errmsg."<br/>
        Prosíme, zkuste to znovu nebo nás kontaktujte a sdělte nám, že
        došlo k chybě na řádku ".$errline." v souboru ".$errfile.", abychom 
        ji mohli prozkoumat.</p>";

  if (($errtype == E_USER_ERROR) || ($errtype == E_ERROR)) {
    echo "<p>Nastala fatální chyba. Program končí.</p>";
    exit;
  }

  echo "<hr/>";
}

// Nastavujeme obsluhující funkci pro chyby.
set_error_handler('my_error_handler');

// Vyvoláváme chyby různých úrovní.
trigger_error('Zavolána funkce trigger_error().', E_USER_NOTICE);
fopen('neexistujicisoubor', 'r');
trigger_error('Tento počítač je béžový.', E_USER_WARNING);
include ('neexistujicisoubor');
trigger_error('Tento počítač se zničí za 15 sekund.', E_USER_ERROR);
?>
