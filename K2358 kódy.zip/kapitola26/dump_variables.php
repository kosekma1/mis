<?php
session_start();

// Na těchto řádcích vypisujeme komentáře jazyka HTML s výstupy funkce
// dump_array().

echo "\n<!-- ZAČÁTEK VÝPISU PROMĚNNÝCH -->\n\n";

echo "<!-- GET PROMĚNNÉ -->\n";
echo "<!-- ".dump_array($_GET)." -->\n";

echo "<!-- POST PROMĚNNÉ -->\n";
echo "<!-- ".dump_array($_POST)." -->\n";

echo "<!-- SESSION PROMĚNNÉ -->\n";
echo "<!-- ".dump_array($_SESSION)." -->\n";

echo "<!-- COOKIE PROMĚNNÉ -->\n";
echo "<!-- ".dump_array($_COOKIE)." -->\n";

echo "\n<!-- KONEC VÝPISU PROMĚNNÝCH -->\n";

// Funkce dump_array() přijímá pole jako argument. Prochází ho a vytváří
// jeden textový řetězec, jenž reprezentuje toto pole.
function dump_array($array) {

  if (is_array($array)) {

    $size = count($array);
    $string = "";
    if ($size) {

      $count = 0;
      $string .= "{ ";

      // Vkládáme klíče a hodnoty všech prvků pole do textového řetězce.
      foreach ($array as $var => $value) {

        $string .= $var." = ".$value;
        if ($count++ < ($size-1)) {
          $string .= ", ";
        }
      }
      $string .= " }";
    }
    return $string;
  } else {
    // Pokud se nejedná o pole, vrátíme původní hodnotu.
    return $array;
  }
}
?>
