<?php
  $date = date(m.d.y');

  //require('nazevsouboru.php');

  /*$i = 10;
  $j = 0;
  $k = $i / $j;*/

  /*$i = 10;
  $k = $i / $_REQUEST['input'];*/

  //neexistujici_funkce();

  //strstr();

?>
