<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Library\Imap\GmailConnection;

class ImapServiceProvider extends ServiceProvider {
  /**
   * Zavádí aplikační služby.
   *
   * @return void
   */
  public function boot() {
    //
  }

  /**
   * Registruje aplikační služby.
   *
   * @return void
   */
  public function register() {
    $this->app->singleton('Imap\Connection\Gmail', function($app) {
      return new GmailConnection(
                     config('imap.gmail.options'),
                     config('imap.gmail.retries'),
                     config('imap.gmail.params')
      );
    });
  }
}

?>
