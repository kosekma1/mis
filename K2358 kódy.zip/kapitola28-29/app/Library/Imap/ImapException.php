<?php

namespace App\Library\Imap;

class ImapException extends \Exception {}

?>
