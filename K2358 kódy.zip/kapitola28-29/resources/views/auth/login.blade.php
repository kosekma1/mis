@extends('layouts.public')

@section('main')
<div class="col-lg-5 col-lg-offset-2">
  <div class="panel panel-default">
    <div class="panel-heading">
      Prosíme, přihlaste se
    </div>
    <div class="panel-body">
      <form action="{{ action('Auth\AuthController@postLoginGmail') }}" method="POST">
        {!! csrf_field() !!}
        <div class="form-group">
          <label for="email">Uživatelské jméno (Gmail)</label>
          <input type="text" name="email" id="email" placeholder="uzivatel@gmail.com">
        </div>
        <div class="form-group">
          <label for="password">Heslo (Gmail)</label>
          <input type="password" name="password" id="password">
        </div>
        <div class="form-group">
          <input type="checkbox" name="remember"> Zapamatovat pověření
        </div>
        <button class="btn btn-block btn-primary" type="submit"><i class="glyphicon glyphicon-lock"></i> Přihlásit se</button>
      </form>
    </div>
  </div>
</div>
@stop
