@extends('layouts.authed')

@section('stylesheets')
  @parent
  <link href="/css/app.css" rel="stylesheet"/>
@stop

@section('main')
  <div class="row">
    <div class="col-md-3">
      <div class="text-center"><h2>E-mailové schránky</h2></div>
      <div class="panel panel-default">
        <div class="panel-body">
          <a href="{{ route('compose') }}" class="btn btn-primary btn-block">Napsat zprávu</a>
          <ul class="folders">
            @foreach($mailboxes as $mailbox)
              <li>
                <a href="{{ route('inbox', ['box' => $mailbox]) }}"><i class="glyphicon glyphicon-inbox"></i> {{{ $formatMailbox($mailbox) }}}</a>
              </li>
            @endforeach
          </ul>
        </div>
      </div>
    </div>

    <div class="col-md-9">
      <div class="text-center">
        @if(is_null($message))
          <h2>Webmail Demo – Nová zpráva</h2>
        @else
          <h2>Webmail Demo – Odpověď</h2>
        @endif
      </div>
      <div class="panel panel-default">
        <div class="panel-body">
          <form action="{{ route('compose.send') }}" method="post">
            {!! csrf_field() !!}
            <div class="header">
              @if(!is_null($message))
                <span class="from">
                  Od: <input class="form-control" type="text" name="from" value="{{ $message->getToEmail() }}"/>
                </span>
                <span class="to">
                  Komu: <input class="form-control" type="text" name="to" value="{{ $message->getFromEmail() }}"/>
                </span>
                <span class="subject">
                  Předmět: <input type="text" class="form-control" name="subject" value="RE: {{{ $message->getSubject() }}}"/>
                </span>
              @else
                <span class="from">
                  Od: <input type="text" name="from" value="" class="form-control"/>
                </span>
                <span class="to">
                  Komu: <input class="form-control" type="text" name="to" value=""/>
                </span>
                <span class="subject">
                  Předmět: <input type="text" name="subject" value="" class="form-control"/>
                </span>
              @endif
            </div>
            <hr/>
            <div class="messageBody">
              <textarea class="form-control replybox" name="message" rows="10" >{{{ $quotedMessage }}}</textarea>
            </div>
            <hr/>
            <input type="submit" class="btn btn-block btn-primary" value="Odeslat"/>
          </form>
        </div>
      </div>
    </div>
  </div>

@stop
