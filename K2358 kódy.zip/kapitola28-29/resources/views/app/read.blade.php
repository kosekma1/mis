@extends('layouts.authed')

@section('stylesheets')
  @parent
  <link href="/css/app.css" rel="stylesheet"/>
@stop

@section('main')
  <div class="row">
    <div class="col-md-3">
      <div class="text-center"><h2>E-mailové schránky</h2></div>
      <div class="panel panel-default">
        <div class="panel-body">
          <a href="{{ route('compose') }}" class="btn btn-primary btn-block">Napsat zprávu</a>
          <ul class="folders">
            @foreach($mailboxes as $mailbox)
              <li>
                <a href="{{ route('inbox', ['box' => $mailbox]) }}"><i class="glyphicon glyphicon-inbox"></i> {{{ $formatMailbox($mailbox) }}}</a>
              </li>
            @endforeach
          </ul>
        </div>
      </div>
    </div>

    <div class="col-md-9">
      <div class="text-center">
        <h2>Webmail Demo – {{{ $formatMailbox($currentMailbox) }}}</h2>
      </div>
      <div class="panel panel-default">
        <div class="panel-body">
          <div class="header">
            <span class="from">
              {{{ $message->getFrom() }}}
            </span>
            <span class="subject">
              {{{ $message->getSubject() }}}
              <span class="date">
                {{{ $message->getDate()->format('j. n. Y') }}}
              </span>
            </span>
          </div>
          <hr/>
          <div class="btn-group pull-right">
            <a href="{{ route('compose', ['id' => $message->getMessageNo(), 'box' => $currentMailbox]) }}" class="btn btn-default"><i class="glyphicon glyphicon-envelope"></i> Odpovědět</a>
            <a href="{{ route('delete', ['id' => $message->getMessageNo(), 'box' => $currentMailbox]) }}" class="btn btn-default"><i class="glyphicon glyphicon-trash"></i> Smazat</a>
          </div>
          <div class="messageBody">
            {{ $message }}
            @if(!empty($message->getAttachments()))
              <hr/>
              @foreach($message->getAttachments() as $part => $attachment)
                <a href="{{ route('read.attachment', ['id' => $message->getMessageNo(), 'partId' => $part, 'box' => $currentMailbox]) }}"><i class="glyphicon glyphicon-download-alt"></i> {{ $attachment->getFilename() }}</a><br/>
              @endforeach
            @endif
          </div>
        </div>
      </div>
    </div>
  </div>

@stop
