@extends('layouts.authed')

@section('stylesheets')
  @parent
  <link href="/css/app.css" rel="stylesheet"/>
@stop

@section('main')
  <div class="row">
    <div class="col-md-3">
      <div class="text-center"><h2>E-mailové schránky</h2></div>
      <div class="panel panel-default">
        <div class="panel-body">
          <a href="{{ route('compose') }}" class="btn btn-primary btn-block">Napsat zprávu</a>
          <ul class="folders">
            @foreach($mailboxes as $mailbox)
              <li>
                <a href="{{ route('inbox', ['box' => $mailbox]) }}"><i class="glyphicon glyphicon-inbox"></i> {{{ $formatMailbox($mailbox) }}}</a>
              </li>
            @endforeach
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="text-center">
        <h2>Webmail Demo – {{{ $formatMailbox($currentMailbox) }}}</h2>
      </div>
      <div class="panel panel-default">
        <div class="panel-body">
          <ul class="messages">
            @foreach($messages as $message)
              <li>
                <a href="{{ route('read', ['id' => $message->getMessageNo(), 'box' => $currentMailbox]) }}" class="nohover">
                  <div class="header">
                    <span class="from">
                      {{{ $message->getFrom() }}}
                      <span class="pull-right">
                        {{{ $message->getDate()->format('j. n. Y h:i') }}}
                      </span>
                    </span>
                    {{{ $message->getSubject() }}}
                  </div>
                </a>
                <hr/>
              </li>
            @endforeach
          </ul>
        </div>
      </div>
      <div class="text-center">
        {{ $paginator->render() }}
      </div>
    </div>
  </div>
@stop
