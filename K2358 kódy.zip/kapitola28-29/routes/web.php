<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('auth/login', [
  'as' => 'login',
  'uses' => 'Auth\AuthController@showLoginForm'
]);

Route::get('auth/logout', 'Auth\AuthController@logout');
Route::post('auth/login', 'Auth\AuthController@postLoginGmail');

Route::group(['middleware' => ['web', 'auth']], function () {

  Route::get('/', 'InboxController@getInbox');

  Route::get('inbox', [
    'as' => 'inbox',
    'uses' => 'InboxController@getInbox'
  ]);

  Route::get('read/{id}', [
    'as' => 'read',
    'uses' => 'InboxController@getMessage'
  ])->where('id', '[0-9]+');

  Route::get('read/{id}/attachment/{partId}', [
    'as' => 'read.attachment',
    'uses' => 'InboxController@getAttachment'
  ])->where('partId', '[0-9]+(\.[0-9]+)*');

  Route::get('compose/{id?}', [
    'as' => 'compose',
    'uses' => 'InboxController@getCompose'
  ])->where('id', '[0-9]+');

  Route::get('inbox/delete/{id}', [
    'as' => 'delete',
    'uses' => 'InboxController@getDelete'
  ])->where('id', '[0-9]+');

  Route::post('compose/send', [
    'as' => 'compose.send',
    'uses' => 'InboxController@postSend'
  ]);

});
