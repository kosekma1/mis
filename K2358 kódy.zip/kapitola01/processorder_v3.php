<?php
  // vytváříme zkrácené názvy proměnných
  $tireqty = $_POST['tireqty'];
  $oilqty = $_POST['oilqty'];
  $sparkqty = $_POST['sparkqty'];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Bobovy autodíly – Výsledek objednávky</title>
  </head>
  <body>
    <h1>Bobovy autodíly</h1>
    <h2>Výsledek objednávky</h2> 
    <?php
      echo "<p>Objednávka byla zpracována ";
      echo date('j. n. Y H:i');
      echo "</p>";

      echo '<p>Vaše objednávka:</p>';
      echo 'pneumatik: '.htmlspecialchars($tireqty).'<br />';
      echo 'lahví oleje: '.htmlspecialchars($oilqty).'<br />';
      echo 'zapalovacích svíček: '.htmlspecialchars($sparkqty).'<br />';
    ?>  
  </body>
</html>
