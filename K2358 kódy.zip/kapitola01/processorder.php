<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Bobovy autodíly – Výsledek objednávky</title>
  </head>
  <body>
    <h1>Bobovy autodíly</h1>
    <h2>Výsledek objednávky</h2> 
    <?php
      echo '<p>Objednávka byla zpracována.</p>';
    ?>
  </body>
</html>
