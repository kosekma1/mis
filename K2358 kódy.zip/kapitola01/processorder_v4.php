<?php
  // vytváříme zkrácené názvy proměnných
  $tireqty = $_POST['tireqty'];
  $oilqty = $_POST['oilqty'];
  $sparkqty = $_POST['sparkqty'];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Bobovy autodíly – Výsledek objednávky</title>
  </head>
  <body>
    <h1>Bobovy autodíly</h1>
    <h2>Výsledek objednávky</h2> 
    <?php
      echo "<p>Objednávka byla zpracována ";
      echo date('j. n. Y H:i');
      echo "</p>";

      echo '<p>Vaše objednávka:</p>';
      echo 'pneumatik: '.htmlspecialchars($tireqty).'<br />';
      echo 'lahví oleje: '.htmlspecialchars($oilqty).'<br />';
      echo 'zapalovacích svíček: '.htmlspecialchars($sparkqty).'<br />';

      $totalqty = 0;
      $totalqty = $tireqty + $oilqty + $sparkqty;
      echo "<p>Objednáno položek: ".$totalqty."<br />";
      $totalamount = 0.00;

      if ($totalqty == 0) {
        echo '<p style="color:red">';
        echo 'Nic jste si neobjednal(a) na předchozí stránce.<br />';
        echo '</p>';
      }

      define('TIREPRICE', 2500);
      define('OILPRICE', 250);
      define('SPARKPRICE', 100);

      $totalamount = $tireqty * TIREPRICE +
                     $oilqty * OILPRICE +
                     $sparkqty * SPARKPRICE;

      echo "Cena: ".number_format($totalamount, 2)." Kč<br />";

      $taxrate = 0.20;  // výše DPH je 20%
      $totalamount = $totalamount * (1 + $taxrate);
      echo "Celková cena s DPH: ".number_format($totalamount,2)." Kč</p>";
    ?>
  </body>
</html>
