<?php
session_start();

echo 'Proměnná $_SESSION[\'session_var\'] obsahuje '.
     $_SESSION['session_var'].'<br />';

unset($_SESSION['session_var']);
?>
<p><a href="page3.php">Další stránka</a></p>
