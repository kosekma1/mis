<?php
session_start();

$_SESSION['session_var'] = "Ahoj světe!";

echo 'Proměnná $_SESSION[\'session_var\'] obsahuje '.
     $_SESSION['session_var'].'<br />';
?>
<p><a href="page2.php">Další stránka</a></p>
