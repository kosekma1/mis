<?php
session_start();

echo 'Proměnná $_SESSION[\'session_var\'] obsahuje '.
     $_SESSION['session_var'].'<br />';

session_destroy();
?>
