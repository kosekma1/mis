<?php
$old_max_execution_time = ini_set('max_execution_time', 120);
echo 'původní časový limit: '.$old_max_execution_time.'<br />';

$max_execution_time = ini_get('max_execution_time');
echo 'nový časový limit: '.$max_execution_time.'<br />';
?>
