<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Výsledky hledání Book-O-Rama</title>
</head>
<body>
  <h1>Výsledky hledání Book-O-Rama</h1>
  <?php
    // vytváříme zkrácené názvy proměnných
    $searchtype = $_POST['searchtype'];
    $searchterm = trim($_POST['searchterm']);

    if (!$searchtype || !$searchterm) {
      echo '<p>Nezadali jste některý z údajů pro vyhledávání.<br/>
        Vraťte se prosím zpět a zkuste to znovu.</p>';
      exit;
    }

    // ověřujeme typ hledání
    switch ($searchtype) {
      case 'Title':
      case 'Author':
      case 'ISBN':
        break;
      default: 
        echo '<p>Zadali jste neplatný typ hledání. <br/>
          Vraťte se prosím zpět a zkuste to znovu.</p>';
        exit;
    }

    @$db = new mysqli('localhost', 'bookorama', 'bookorama123', 'books');
    if (mysqli_connect_errno()) {
      echo '<p>Chyba: Nepodařilo se připojit k databázi.<br/>
        Zkuste to prosím později.</p>';
      exit;
    }

    $query = "SELECT ISBN, Author, Title, Price
                FROM Books
                WHERE $searchtype LIKE ?";
    $stmt = $db->prepare($query);
    $searchterm = '%'.$searchterm.'%';
    $stmt->bind_param('s', $searchterm);
    $stmt->execute();
    $stmt->store_result();
  
    $stmt->bind_result($isbn, $author, $title, $price);

    echo "<p>Počet nalezených knih: ".$stmt->num_rows."</p>";

    while($stmt->fetch()) {
      echo "<p><strong>Název: ".$title."</strong>";
      echo "<br />Autor: ".$author;
      echo "<br />ISBN: ".$isbn;
      echo "<br />Cena: ".number_format($price,2)." Kč</p>";
    }

    $stmt->free_result();
    $db->close();
  ?>
</body>
</html>
