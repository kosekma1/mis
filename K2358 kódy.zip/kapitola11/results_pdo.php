<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Výsledky hledání Book-O-Rama</title>
</head>
<body>
  <h1>Výsledky hledání Book-O-Rama</h1>
  <?php
    // vytváříme zkrácené názvy proměnných
    $searchtype = $_POST['searchtype'];
    $searchterm = trim($_POST['searchterm']);

    if (!$searchtype || !$searchterm) {
      echo '<p>Nezadali jste některý z údajů pro vyhledávání.<br/>
        Vraťte se prosím zpět a zkuste to znovu.</p>';
      exit;
    }

    // ověřujeme typ hledání
    switch ($searchtype) {
      case 'Title':
      case 'Author':
      case 'ISBN':
        break;
      default:
        echo '<p>Zadali jste neplatný typ hledání. <br/>
          Vraťte se prosím zpět a zkuste to znovu.</p>';
        exit;
    }

    // nastavení pro PDO
    $user = 'bookorama';
    $pass = 'bookorama123';
    $host = 'localhost';
    $db_name = 'books';

    // nastavení názvu DSN
    $dsn = "mysql:host=$host;dbname=$db_name";

    // připojení k databázi
    try {
      $db = new PDO($dsn, $user, $pass);

      // provedení dotazu
      $query = "SELECT ISBN, Author, Title, Price
                  FROM Books
                  WHERE $searchtype
                  LIKE :searchterm";
      $stmt = $db->prepare($query);
      $searchterm = '%'.$searchterm.'%';
      $stmt->bindParam(':searchterm', $searchterm);
      $stmt->execute();

      // zobrazujeme počet nalezených řádků
      echo "<p>Počet nalezených knih: ".$stmt->rowCount()."</p>";

      // zobrazujeme jednotlivé řádky
      while($result = $stmt->fetch(PDO::FETCH_OBJ)) {
        echo "<p><strong>Název: ".$result->Title."</strong>";
        echo "<br />Autor: ".$result->Author;
        echo "<br />ISBN: ".$result->ISBN;
        echo "<br />Cena: ".number_format($result->Price, 2)." Kč </p>";
      }

      // odpojení od databáze
      $db = NULL;
    } catch (PDOException $e) {
      echo "Chyba: ".$e->getMessage();
      exit;
    }
  ?>
</body>
</html>
