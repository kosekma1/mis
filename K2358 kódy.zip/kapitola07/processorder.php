<?php
  require_once("file_exceptions.php");

  // vytváříme zkrácené názvy proměnných
  $tireqty = (int) $_POST['tireqty'];                                           
  $oilqty = (int) $_POST['oilqty'];                                             
  $sparkqty = (int) $_POST['sparkqty'];                                         
  $address = preg_replace('/\t|\R/',' ',$_POST['address']);                     
  $document_root = $_SERVER['DOCUMENT_ROOT'];                                   
  $date = date('j. n. Y H:i'); 
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Bobovy autodíly – Výsledek objednávky</title>
  </head>
  <body>
    <h1>Bobovy autodíly</h1>
    <h2>Výsledek objednávky</h2>
    <?php
      echo "<p>Objednávka byla zpracována ".$date."</p>";
      echo '<p>Vaše objednávka:</p>';

      $totalqty = 0;
      $totalamount = 0.00;

      define('TIREPRICE', 100);
      define('OILPRICE', 10);
      define('SPARKPRICE', 4);

      $totalqty = $tireqty + $oilqty + $sparkqty;
      echo "<p>Objednáno položek: ".$totalqty."<br />";

      if ($totalqty == 0) {
        echo "Nic jste si neobjednal(a) na předchozí stránce.<br />";
      } else {
        if ($tireqty > 0) {
          echo 'pneumatik: '.htmlspecialchars($tireqty).'<br />';
        }
        if ($oilqty > 0) {
          echo 'lahví oleje: '.htmlspecialchars($oilqty).'<br />';
        }
        if ($sparkqty > 0) {
          echo 'zapalovacích svíček: '.htmlspecialchars($sparkqty).'<br />';
        }
      }


      $totalamount = $tireqty * TIREPRICE
                   + $oilqty * OILPRICE
                   + $sparkqty * SPARKPRICE;

      echo "Cena: ".number_format($totalamount, 2)." Kč<br />";

      $taxrate = 0.20;  // výše DPH je 20%
      $totalamount = $totalamount * (1 + $taxrate);
      echo "Celková cena s DPH: ".number_format($totalamount,2)." Kč</p>";

      echo "<p>Doručovací adresa: ".htmlspecialchars($address)."</p>";

      $outputstring = $date."\t".$tireqty." pneumatik\t".
                      $oilqty." lahví oleje\t".
                      $sparkqty." zapalovacích svíček\t".$totalamount." Kč\t".
                      $address."\n";

      // otevřeme soubor pro doplnění
      try {
        if (!($fp = @fopen("$document_root/../orders/orders.txt", 'ab'))) {
          throw new FileOpenException();
        }
      
        if (!flock($fp, LOCK_EX)) {
          throw new FileLockException();
        }
      
        if (!fwrite($fp, $outputstring, strlen($outputstring))) {
          throw new FileWriteException();
        }

        flock($fp, LOCK_UN);
        fclose($fp);
        echo "<p>Objednávka byla uložena.</p>";
      } catch (FileOpenException $foe) {
        echo "<p><strong>Soubor s objednávkami se nepodařilo otevřít.<br/>
              Prosíme, kontaktujte našeho webmastera, který vám rád
              pomůže.</strong></p>";
      } catch (Exception $e) {
        echo "<p><strong>Vaše objednávka nemohla být zpracována. Zkuste to
              prosím později.</strong></p>";
      }
    ?>
  </body>
</html>
