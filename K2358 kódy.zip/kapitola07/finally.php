<?php
  try {
    // provedení nějakého úkolu, možná vyhození pár výjimek
  } catch(Exception $e) {
    // zpracování výjimky
  } finally {
    echo 'Provede se vždy!';
  }

?>
