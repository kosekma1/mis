<?php

try  {
  throw new Exception("Nastala strašná chyba.", 42);
} catch (Exception $e) {
  echo "Výjimka ". $e->getCode(). ": ". $e->getMessage()."<br />".
  " v ". $e->getFile(). " na řádku ". $e->getLine(). "<br />";
}

?>
