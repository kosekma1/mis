<?php

class MyException extends Exception {
  function __toString() {
    return "<strong>Výjimka ".$this->getCode().
      "</strong>: ".$this->getMessage()."<br />".
      "v ".$this->getFile()." na řádku ".$this->getLine()."<br/>";
  }
}

try {
  throw new MyException("Nastala strašná chyba.", 42);
} catch (MyException $m) {
  echo $m;
}

?>
